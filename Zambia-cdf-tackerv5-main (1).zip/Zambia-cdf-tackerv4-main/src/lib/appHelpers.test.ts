import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isImageFile,
  generateNextSequentialId,
  sanitizeForFirestore,
  estimateDocumentBytes,
  buildCompactAiContext,
} from './appHelpers';

test('isImageFile detects image MIME types and falls back to filename extensions', () => {
  assert.equal(isImageFile('receipt.jpg', 'image/jpeg'), true);
  assert.equal(isImageFile('photo.PNG', ''), true);
  assert.equal(isImageFile('site.heic', ''), true);
  assert.equal(isImageFile('notes.pdf', 'application/pdf'), false);
  assert.equal(isImageFile('document.txt', ''), false);
});

test('generateNextSequentialId advances past max numeric suffix even with gaps', () => {
  assert.equal(generateNextSequentialId('RPT-', []), 'RPT-001');
  assert.equal(
    generateNextSequentialId('RPT-', ['RPT-001', 'RPT-005', 'RPT-003']),
    'RPT-006'
  );
  assert.equal(
    generateNextSequentialId('P', ['P001', 'P238', 'legacy-id']),
    'P239'
  );
  assert.equal(
    generateNextSequentialId('APP-', ['APP-009', 'APP-010']),
    'APP-011'
  );
});

test('sanitizeForFirestore recursively removes undefined object keys without mutating arrays', () => {
  const dirty = {
    id: 'RPT-001',
    email: undefined,
    nested: {
      ok: 'yes',
      skip: undefined,
    },
    items: [1, undefined, { a: 'x', b: undefined }],
  };
  const clean = sanitizeForFirestore(dirty);
  assert.deepEqual(clean, {
    id: 'RPT-001',
    nested: { ok: 'yes' },
    items: [1, { a: 'x' }],
  });
  assert.equal('email' in clean, false);
});

test('estimateDocumentBytes accurately flags payloads approaching Firestore 1 MiB limit', () => {
  const smallDoc = { id: 'P001', name: 'Test School' };
  assert.ok(estimateDocumentBytes(smallDoc) < 100);

  const largeDoc = { id: 'P001', blob: 'A'.repeat(950_000) };
  assert.ok(estimateDocumentBytes(largeDoc) > 950_000);
});

test('buildCompactAiContext strips heavy base64 dataUrl and photoUrl fields', () => {
  const ctx = buildCompactAiContext({
    projects: [
      {
        id: 'P001',
        name: 'Clinic',
        constituency: 'Matero',
        province: 'Lusaka',
        sector: 'Health',
        budget: 100000,
        spent: 50000,
        pct: 50,
        status: 'ongoing',
        mp: 'Hon. MP',
        dailyLogs: [
          {
            id: 'DAY-1',
            date: '2026-11-18',
            amount: 50000,
            whereItGoes: 'Roofing',
            materialsUsed: 'Iron sheets',
            contractorName: 'BuildCo',
            recordedBy: 'Admin',
            recordedAt: '2026-11-18T00:00:00Z',
            attachments: [
              {
                id: 'ATT-1',
                name: 'receipt.jpg',
                type: 'image/jpeg',
                dataUrl: 'data:image/jpeg;base64,' + 'X'.repeat(50000),
                uploadedAt: '2026-11-18T00:00:00Z',
              },
            ],
          },
        ],
      },
    ],
    reports: [
      {
        id: 'RPT-001',
        constituency: 'Matero',
        type: 'Ghost project',
        proj: 'Clinic',
        amount: '50000',
        contact: 'Anonymous',
        desc: 'Issue spotted',
        date: '2026-11-18',
        status: 'Received',
        acc: true,
        photoUrl: 'data:image/jpeg;base64,' + 'Y'.repeat(50000),
      },
    ],
  });

  const serialized = JSON.stringify(ctx);
  assert.equal(serialized.includes('XXXXX'), false);
  assert.equal(serialized.includes('YYYYY'), false);
  assert.equal(ctx.projects[0].attachmentCount, 1);
  assert.equal(ctx.projects[0].dailyLogs[0].attachmentCount, 1);
  assert.equal(ctx.reports[0].hasEvidencePhoto, true);
});
