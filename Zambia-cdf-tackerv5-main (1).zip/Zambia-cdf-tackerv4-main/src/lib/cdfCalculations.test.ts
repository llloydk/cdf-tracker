import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateProjectMetrics,
  buildSyncedProjectPayload,
  calculateConstituencyMetrics,
  computeProjectSpent,
  CDF_PER_CONSTITUENCY,
} from './cdfCalculations';
import { Project, Report } from '../types';
import { ConstituencyInfo } from '../constituencies';

const baseProject: Project = {
  id: 'P100',
  name: 'Test School Block',
  constituency: 'TestConst',
  province: 'Lusaka',
  sector: 'Education',
  budget: 1_000_000,
  spent: 0,
  pct: 0,
  status: 'planned',
  mp: 'Hon. Tester',
};

const baseConstituency: ConstituencyInfo = {
  name: 'TestConst',
  province: 'Lusaka',
  mp: 'Hon. Tester',
  party: 'UPND',
  score: 0,
  allocated: 30_400_000,
};

test('newly created project with zero spent has full remaining budget and 0% transparency', () => {
  const m = calculateProjectMetrics(baseProject);
  assert.equal(m.budget, 1_000_000);
  assert.equal(m.spent, 0);
  assert.equal(m.remaining, 1_000_000);
  assert.equal(m.pct, 0);
  assert.equal(m.transparencyPct, 0);
});

test('logging daily fund usage with materials, contractor, where it goes, and uploaded attachment updates spent, remaining, pct, and transparencyPct', () => {
  const withLog: Project = {
    ...baseProject,
    status: 'ongoing',
    dailyLogs: [
      {
        id: 'LOG-1',
        date: '2026-11-17',
        amount: 500_000,
        whereItGoes: 'Classroom Block Foundation & Slab',
        materialsUsed: '250 bags cement, 20t river sand, steel rebar',
        contractorName: 'Zambezi Civil Works Ltd',
        attachments: [
          {
            id: 'ATT-1',
            name: 'receipt.jpg',
            type: 'image/jpeg',
            dataUrl: 'data:image/jpeg;base64,abc',
            uploadedAt: '2026-11-17T10:00:00Z',
          },
        ],
        recordedBy: 'Admin',
        recordedAt: '2026-11-17T10:00:00Z',
      },
    ],
  };

  const m = calculateProjectMetrics(withLog);
  assert.equal(m.spent, 500_000);
  assert.equal(m.remaining, 500_000);
  assert.equal(m.pct, 50);
  // 50% of 50 utilization pts = 25 + 100% of 50 documentation pts = 50 -> 75%
  assert.equal(m.transparencyPct, 75);
  assert.equal(m.latestContractor, 'Zambezi Civil Works Ltd');
});

test('changing budget automatically recalculates remaining fund, pct, and transparencyPct', () => {
  const syncedAfterLog = buildSyncedProjectPayload(baseProject, {
    status: 'ongoing',
    dailyLogs: [
      {
        id: 'LOG-1',
        date: '2026-11-17',
        amount: 500_000,
        whereItGoes: 'Roofing sheets & timber',
        materialsUsed: '100 iron sheets, 40 beams',
        contractorName: 'Kafue Builders Co.',
        attachments: [
          {
            id: 'ATT-1',
            name: 'invoice.png',
            type: 'image/png',
            dataUrl: 'data:image/png;base64,xyz',
            uploadedAt: '2026-11-17T11:00:00Z',
          },
        ],
        recordedBy: 'Admin',
        recordedAt: '2026-11-17T11:00:00Z',
      },
    ],
  });
  assert.equal(syncedAfterLog.spent, 500_000);
  assert.equal(syncedAfterLog.remaining, 500_000);
  assert.equal(syncedAfterLog.pct, 50);
  assert.equal(syncedAfterLog.transparencyPct, 75);

  // Admin doubles the project budget to 2,000,000
  const afterBudgetIncrease = buildSyncedProjectPayload(syncedAfterLog, { budget: 2_000_000 });
  assert.equal(afterBudgetIncrease.spent, 500_000);
  assert.equal(afterBudgetIncrease.remaining, 1_500_000);
  assert.equal(afterBudgetIncrease.pct, 25);
  // 0.25 * 50 = 12.5 + 50 = 62.5 -> 63%
  assert.equal(afterBudgetIncrease.transparencyPct, 63);

  // Admin lowers budget to 500,000 -> 100% used, 0 remaining, 100% transparency
  const afterBudgetMatch = buildSyncedProjectPayload(syncedAfterLog, { budget: 500_000 });
  assert.equal(afterBudgetMatch.remaining, 0);
  assert.equal(afterBudgetMatch.pct, 100);
  assert.equal(afterBudgetMatch.transparencyPct, 100);
});

test('seeded project with existing spent preserves baseSpent when daily logs are added', () => {
  const seeded: Project = {
    ...baseProject,
    budget: 1_200_000,
    spent: 400_000,
    baseSpent: 400_000,
    status: 'ongoing',
    dailyLogs: [
      {
        id: 'LOG-2',
        date: '2026-11-17',
        amount: 200_000,
        whereItGoes: 'Plumbing & borehole pump',
        materialsUsed: 'Submersible pump, PVC pipes',
        contractorName: 'AquaZambia Ltd',
        recordedBy: 'Admin',
        recordedAt: '2026-11-17T12:00:00Z',
      },
    ],
  };

  assert.equal(computeProjectSpent(seeded), 600_000);
  const m = calculateProjectMetrics(seeded);
  assert.equal(m.remaining, 600_000);
  assert.equal(m.pct, 50);
});

test('newly spawned constituency with zero projects has 0% transparency and full remaining allocation', () => {
  const cm = calculateConstituencyMetrics(baseConstituency, [], []);
  assert.equal(cm.projectsCount, 0);
  assert.equal(cm.score, 0);
  assert.equal(cm.spent, 0);
  assert.equal(cm.remaining, CDF_PER_CONSTITUENCY);
});

test('constituency transparency matches project maintenance registry entries and updates when allocation changes', () => {
  const projectWithFullProof = buildSyncedProjectPayload(baseProject, {
    budget: 10_000_000,
    status: 'ongoing',
    dailyLogs: [
      {
        id: 'LOG-3',
        date: '2026-11-17',
        amount: 5_000_000,
        whereItGoes: 'Feeder road grading & culverts',
        materialsUsed: 'Laterite gravel, concrete culverts',
        contractorName: 'Copperbelt Roads Ltd',
        attachments: [
          {
            id: 'ATT-2',
            name: 'waybill.jpg',
            type: 'image/jpeg',
            dataUrl: 'data:image/jpeg;base64,123',
            uploadedAt: '2026-11-17T12:00:00Z',
          },
        ],
        recordedBy: 'Admin',
        recordedAt: '2026-11-17T12:00:00Z',
      },
    ],
  });

  const cmInitial = calculateConstituencyMetrics(
    { ...baseConstituency, allocated: 20_000_000 },
    [projectWithFullProof],
    [] as Report[]
  );
  assert.equal(cmInitial.spent, 5_000_000);
  assert.equal(cmInitial.remaining, 15_000_000);
  // project transparency = 75 -> 75 * 0.75 = 56.25; alloc util = (5M/20M)*25 = 6.25 -> 63
  assert.equal(cmInitial.score, 63);

  // Admin lowers constituency allocation budget to 10,000,000 -> remaining & transparency auto-update
  const cmReducedAlloc = calculateConstituencyMetrics(
    { ...baseConstituency, allocated: 10_000_000 },
    [projectWithFullProof],
    []
  );
  assert.equal(cmReducedAlloc.remaining, 5_000_000);
  // 56.25 + (5M/10M)*25 (12.5) = 68.75 -> 69
  assert.equal(cmReducedAlloc.score, 69);
});
