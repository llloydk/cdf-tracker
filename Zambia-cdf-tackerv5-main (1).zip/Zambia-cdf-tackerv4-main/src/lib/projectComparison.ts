import { Project } from '../types';
import { calculateProjectMetrics, ProjectMetrics } from './cdfCalculations';

export interface ProjectComparisonItem {
  project: Project;
  metrics: ProjectMetrics;
  budgetEfficiencyPct: number;
  efficiencyNote: string;
}

export interface ProjectComparisonResult {
  left: ProjectComparisonItem;
  right: ProjectComparisonItem;
  efficiencyDiff: number; // left - right
  transparencyDiff: number; // left - right
  utilizationDiff: number; // left - right
  budgetDiff: number; // left - right
  spentDiff: number; // left - right
  remainingDiff: number; // left - right
  efficiencyLeader: 'left' | 'right' | 'tie';
  transparencyLeader: 'left' | 'right' | 'tie';
  overallLeader: 'left' | 'right' | 'tie';
}

/**
 * Toggles a project ID inside the comparison selection list up to `maxSelection` items.
 */
export function toggleProjectSelection(
  selectedIds: string[],
  projectId: string,
  maxSelection = 2
): string[] {
  if (selectedIds.includes(projectId)) {
    return selectedIds.filter((id) => id !== projectId);
  }
  if (selectedIds.length >= maxSelection) {
    return selectedIds;
  }
  return [...selectedIds, projectId];
}

/**
 * Computes a 0-100 Budget Efficiency percentage for a project based on fund
 * utilization, delivery status, and budget discipline:
 * - Planned projects with 0 spend start at 0%.
 * - Over-budget projects are penalized by their overspend ratio.
 * - Stalled projects incur a -30 pt delivery drag penalty.
 * - Completed projects within budget receive a small completion efficiency bonus (up to 100%).
 */
export function computeBudgetEfficiency(
  project: Project,
  metrics: ProjectMetrics = calculateProjectMetrics(project)
): { score: number; note: string } {
  if (metrics.budget <= 0) {
    return { score: 0, note: 'No budget allocated yet' };
  }

  if (project.status === 'planned' && metrics.spent === 0) {
    return { score: 0, note: 'Planned — awaiting disbursement' };
  }

  const rawUtil = (metrics.spent / metrics.budget) * 100;

  if (metrics.overBudget) {
    const overspendRatio = ((metrics.spent - metrics.budget) / metrics.budget) * 100;
    const score = Math.max(0, Math.min(100, Math.round(100 - overspendRatio)));
    return {
      score,
      note: `Over budget by ${Math.round(overspendRatio)}%`,
    };
  }

  if (project.status === 'stalled') {
    const score = Math.max(0, Math.round(Math.min(100, rawUtil) - 30));
    return {
      score,
      note: 'Stalled delivery (-30 pts drag)',
    };
  }

  if (project.status === 'complete') {
    const underBudgetBonus = metrics.spent < metrics.budget ? 4 : 0;
    const score = Math.min(100, Math.round(rawUtil + underBudgetBonus));
    return {
      score,
      note: metrics.spent < metrics.budget ? 'Completed under budget' : 'Completed on budget',
    };
  }

  const score = Math.max(0, Math.min(100, Math.round(rawUtil)));
  return {
    score,
    note: `${score}% of allocation actively utilized`,
  };
}

function getLeader(leftVal: number, rightVal: number): 'left' | 'right' | 'tie' {
  if (leftVal > rightVal) return 'left';
  if (rightVal > leftVal) return 'right';
  return 'tie';
}

/**
 * Produces a complete side-by-side comparison of two projects across
 * budget efficiency, transparency score, financial utilization, and status.
 */
export function compareTwoProjects(
  projectA: Project,
  projectB: Project
): ProjectComparisonResult {
  const metricsA = calculateProjectMetrics(projectA);
  const metricsB = calculateProjectMetrics(projectB);

  const effA = computeBudgetEfficiency(projectA, metricsA);
  const effB = computeBudgetEfficiency(projectB, metricsB);

  const left: ProjectComparisonItem = {
    project: projectA,
    metrics: metricsA,
    budgetEfficiencyPct: effA.score,
    efficiencyNote: effA.note,
  };

  const right: ProjectComparisonItem = {
    project: projectB,
    metrics: metricsB,
    budgetEfficiencyPct: effB.score,
    efficiencyNote: effB.note,
  };

  const efficiencyDiff = left.budgetEfficiencyPct - right.budgetEfficiencyPct;
  const transparencyDiff = left.metrics.transparencyPct - right.metrics.transparencyPct;
  const utilizationDiff = left.metrics.pct - right.metrics.pct;
  const budgetDiff = left.metrics.budget - right.metrics.budget;
  const spentDiff = left.metrics.spent - right.metrics.spent;
  const remainingDiff = left.metrics.remaining - right.metrics.remaining;

  const efficiencyLeader = getLeader(left.budgetEfficiencyPct, right.budgetEfficiencyPct);
  const transparencyLeader = getLeader(
    left.metrics.transparencyPct,
    right.metrics.transparencyPct
  );

  const leftComposite = left.budgetEfficiencyPct + left.metrics.transparencyPct;
  const rightComposite = right.budgetEfficiencyPct + right.metrics.transparencyPct;
  const overallLeader = getLeader(leftComposite, rightComposite);

  return {
    left,
    right,
    efficiencyDiff,
    transparencyDiff,
    utilizationDiff,
    budgetDiff,
    spentDiff,
    remainingDiff,
    efficiencyLeader,
    transparencyLeader,
    overallLeader,
  };
}
