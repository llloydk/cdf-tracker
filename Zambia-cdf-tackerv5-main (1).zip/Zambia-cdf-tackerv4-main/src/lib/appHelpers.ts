import { Application, Project, ProjectRequest, Report } from '../types';

const IMAGE_EXT_REGEX = /\.(jpe?g|png|webp|gif|bmp|avif|heic|heif)$/i;

/**
 * Checks whether a selected file is an image even if a mobile browser
 * omits `file.type` (empty string) and only supplies a filename extension.
 */
export function isImageFile(fileName: string, mimeType: string): boolean {
  const mime = (mimeType || '').trim().toLowerCase();
  if (mime.startsWith('image/')) return true;
  if (!mime && IMAGE_EXT_REGEX.test((fileName || '').trim())) return true;
  return false;
}

/**
 * Generates the next sequential ID (e.g. RPT-004, REQ-012, APP-005, P240)
 * using the maximum existing numeric suffix so deleted records or scoped
 * admin lists never cause overwriting collisions.
 */
export function generateNextSequentialId(
  prefix: string,
  existingIds: Array<string | undefined | null>,
  padLength = 3
): string {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const matcher = new RegExp(`^${escapedPrefix}(\\d+)$`, 'i');
  const maxNum = existingIds.reduce((max, id) => {
    if (!id) return max;
    const match = matcher.exec(id.trim());
    if (!match) return max;
    const num = parseInt(match[1], 10);
    return Number.isFinite(num) ? Math.max(max, num) : max;
  }, 0);
  return `${prefix}${String(maxNum + 1).padStart(padLength, '0')}`;
}

/**
 * Recursively strips `undefined` object properties so Firestore `setDoc` /
 * `updateDoc` calls never fail with "Unsupported field value: undefined".
 */
export function sanitizeForFirestore<T>(value: T): T {
  if (value === null || value === undefined) {
    return value;
  }
  if (Array.isArray(value)) {
    return value
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item)) as unknown as T;
  }
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
      if (val !== undefined) {
        out[key] = sanitizeForFirestore(val);
      }
    }
    return out as T;
  }
  return value;
}

/**
 * Estimates serialized UTF-8 payload byte size for Firestore 1 MiB (1,048,576 bytes)
 * document size safety checks before committing attachments.
 */
export function estimateDocumentBytes(docData: unknown): number {
  const json = JSON.stringify(sanitizeForFirestore(docData)) || '';
  return new TextEncoder().encode(json).length;
}

/**
 * Produces a lightweight snapshot for Gemini / AI REST routes with base64 media
 * strings (`dataUrl`, `photoUrl`) stripped so uploads never cause 413 Payload Too Large.
 */
export function buildCompactAiContext(params: {
  projects?: Project[];
  reports?: Report[];
  requests?: ProjectRequest[];
  applications?: Application[];
}) {
  const projects = (params.projects || []).map((p) => {
    const logs = p.dailyLogs || [];
    const attachmentCount = logs.reduce((sum, l) => sum + (l.attachments?.length || 0), 0);
    return {
      id: p.id,
      name: p.name,
      constituency: p.constituency,
      province: p.province,
      sector: p.sector,
      budget: p.budget,
      spent: p.spent,
      remaining: p.remaining,
      pct: p.pct,
      transparencyPct: p.transparencyPct,
      status: p.status,
      mp: p.mp,
      contractor: p.contractor,
      dailyLogCount: logs.length,
      attachmentCount,
      dailyLogs: logs.slice(0, 10).map((l) => ({
        date: l.date,
        amount: l.amount,
        whereItGoes: l.whereItGoes,
        materialsUsed: l.materialsUsed,
        contractorName: l.contractorName,
        attachmentCount: l.attachments?.length || 0,
      })),
    };
  });

  const reports = (params.reports || []).map((r) => ({
    id: r.id,
    constituency: r.constituency,
    type: r.type,
    proj: r.proj,
    amount: r.amount,
    desc: r.desc,
    date: r.date,
    status: r.status,
    acc: r.acc,
    hasEvidencePhoto: Boolean(r.photoUrl),
  }));

  const requests = (params.requests || []).map((req) => ({
    id: req.id,
    constituency: req.constituency,
    sector: req.sector,
    name: req.name,
    cost: req.cost,
    beneficiaries: req.beneficiaries,
    desc: req.desc,
    date: req.date,
    status: req.status,
    votes: req.votes || 0,
    rejects: req.rejects || 0,
  }));

  const applications = (params.applications || []).map((app) => ({
    id: app.id,
    category: app.category,
    applicantName: app.applicantName,
    nrc: app.nrc,
    constituency: app.constituency,
    amount: app.amount,
    purpose: app.purpose,
    status: app.status,
    date: app.date,
  }));

  return { projects, reports, requests, applications };
}
