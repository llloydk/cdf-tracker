import test from 'node:test';
import assert from 'node:assert/strict';
import { Project } from '../types';
import {
  compareTwoProjects,
  computeBudgetEfficiency,
  toggleProjectSelection,
} from './projectComparison';

const makeProject = (overrides: Partial<Project>): Project => ({
  id: 'P001',
  name: 'Test Project',
  constituency: 'Matero',
  province: 'Lusaka',
  sector: 'Education',
  budget: 1_000_000,
  spent: 500_000,
  pct: 50,
  status: 'ongoing',
  mp: 'Hon. Test MP',
  ...overrides,
});

test('toggleProjectSelection adds up to 2 projects, toggles off, and blocks a 3rd until deselected', () => {
  let sel: string[] = [];
  sel = toggleProjectSelection(sel, 'P001');
  assert.deepEqual(sel, ['P001']);

  sel = toggleProjectSelection(sel, 'P002');
  assert.deepEqual(sel, ['P001', 'P002']);

  // Attempting to select a 3rd project keeps the existing 2
  sel = toggleProjectSelection(sel, 'P003');
  assert.deepEqual(sel, ['P001', 'P002']);

  // Unchecking P001 allows selecting P003
  sel = toggleProjectSelection(sel, 'P001');
  assert.deepEqual(sel, ['P002']);

  sel = toggleProjectSelection(sel, 'P003');
  assert.deepEqual(sel, ['P002', 'P003']);
});

test('computeBudgetEfficiency rewards completed under-budget projects and penalizes stalled or over-budget projects', () => {
  const completeUnder = makeProject({
    id: 'P1',
    budget: 850_000,
    spent: 820_000,
    status: 'complete',
  });
  const stalledProj = makeProject({
    id: 'P2',
    budget: 1_000_000,
    spent: 500_000,
    status: 'stalled',
  });
  const overBudgetProj = makeProject({
    id: 'P3',
    budget: 1_000_000,
    spent: 1_250_000,
    status: 'ongoing',
  });
  const zeroBudgetProj = makeProject({
    id: 'P4',
    budget: 0,
    spent: 0,
    status: 'planned',
  });

  const effComplete = computeBudgetEfficiency(completeUnder);
  const effStalled = computeBudgetEfficiency(stalledProj);
  const effOver = computeBudgetEfficiency(overBudgetProj);
  const effZero = computeBudgetEfficiency(zeroBudgetProj);

  assert.equal(effComplete.score, 100);
  assert.equal(effStalled.score, 20);
  assert.equal(effOver.score, 75);
  assert.equal(effZero.score, 0);
});

test('compareTwoProjects computes diffs and leaders across efficiency, transparency, and financials', () => {
  const schoolComplete = makeProject({
    id: 'P001',
    name: 'Matero Primary School Block',
    budget: 850_000,
    spent: 820_000,
    status: 'complete',
  });

  const roadStalled = makeProject({
    id: 'P003',
    name: 'Chawama Road Rehabilitation',
    constituency: 'Chawama',
    sector: 'Roads',
    budget: 2_500_000,
    spent: 0,
    status: 'stalled',
  });

  const result = compareTwoProjects(schoolComplete, roadStalled);

  assert.equal(result.left.budgetEfficiencyPct, 100);
  assert.equal(result.right.budgetEfficiencyPct, 0);
  assert.equal(result.efficiencyDiff, 100);
  assert.equal(result.efficiencyLeader, 'left');

  assert.equal(result.left.metrics.transparencyPct, 83);
  assert.equal(result.right.metrics.transparencyPct, 0);
  assert.equal(result.transparencyDiff, 83);
  assert.equal(result.transparencyLeader, 'left');
  assert.equal(result.overallLeader, 'left');

  assert.equal(result.budgetDiff, -1_650_000);
  assert.equal(result.spentDiff, 820_000);
});

test('compareTwoProjects reports tie when both projects have identical efficiency and transparency', () => {
  const a = makeProject({ id: 'PA', budget: 1_000_000, spent: 500_000, status: 'ongoing' });
  const b = makeProject({ id: 'PB', budget: 1_000_000, spent: 500_000, status: 'ongoing' });

  const result = compareTwoProjects(a, b);
  assert.equal(result.efficiencyDiff, 0);
  assert.equal(result.transparencyDiff, 0);
  assert.equal(result.efficiencyLeader, 'tie');
  assert.equal(result.transparencyLeader, 'tie');
  assert.equal(result.overallLeader, 'tie');
});
