import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getApplicationCategoryColor,
  getProjectStatusColor,
  isValidCoordinatePair,
  resolveApplicationCoordinates,
  resolveConstituencyCenter,
  resolveProjectCoordinates,
} from './zambiaGeo';

test('resolveProjectCoordinates uses explicit GPS coordinates when present', () => {
  const res = resolveProjectCoordinates({
    id: 'P001',
    constituency: 'Matero',
    province: 'Lusaka',
    lat: -15.371234,
    lng: 28.261234,
  });
  assert.equal(res.source, 'gps');
  assert.equal(res.lat, -15.371234);
  assert.equal(res.lng, 28.261234);
});

test('resolveProjectCoordinates resolves deterministic constituency coordinates inside Zambia', () => {
  const a = resolveProjectCoordinates({
    id: 'P010',
    constituency: 'Chipata Central',
    province: 'Eastern',
  });
  const b = resolveProjectCoordinates({
    id: 'P010',
    constituency: 'Chipata Central',
    province: 'Eastern',
  });
  assert.deepEqual(a, b);
  assert.equal(a.source, 'constituency');
  assert.ok(a.lat >= -18.0 && a.lat <= -8.3);
  assert.ok(a.lng >= 22.0 && a.lng <= 33.6);
  // Chipata is in Eastern Zambia (~32.65E)
  assert.ok(a.lng > 32.0);
});

test('resolveProjectCoordinates falls back to province centroid for unmapped constituency names', () => {
  const res = resolveProjectCoordinates({
    id: 'PF999',
    constituency: 'Custom Remote Constituency',
    province: 'Western',
  });
  assert.equal(res.source, 'province');
  // Mongu/Western province is ~23.1E
  assert.ok(res.lng < 24.5);
  assert.ok(res.lat >= -18.0 && res.lat <= -8.3);
});

test('resolveApplicationCoordinates prioritizes exact GPS coordinates and falls back cleanly', () => {
  const exact = resolveApplicationCoordinates({
    id: 'APP-001',
    constituency: 'Kanyama',
    lat: -15.43,
    lng: 28.24,
  });
  assert.equal(exact.source, 'gps');
  assert.equal(exact.lat, -15.43);
  assert.equal(exact.lng, 28.24);

  const fallback = resolveApplicationCoordinates({
    id: 'APP-002',
    constituency: 'Livingstone Central',
  });
  assert.equal(fallback.source, 'constituency');
  assert.ok(fallback.lat < -17.0); // Livingstone is in the far south
});

test('resolveConstituencyCenter finds constituency center and province fallback', () => {
  const kitwe = resolveConstituencyCenter('Nkana', 'Copperbelt');
  assert.equal(kitwe.source, 'constituency');
  assert.ok(Math.abs(kitwe.lat - -12.815) < 0.01);

  const custom = resolveConstituencyCenter('Unknown Ward', 'North Western');
  assert.equal(custom.source, 'province');
  assert.ok(Math.abs(custom.lat - -12.1688) < 0.01);
});

test('isValidCoordinatePair validates finite lat/lng bounds', () => {
  assert.equal(isValidCoordinatePair(-15.4, 28.3), true);
  assert.equal(isValidCoordinatePair(undefined, 28.3), false);
  assert.equal(isValidCoordinatePair(Number.NaN, 28.3), false);
  assert.equal(isValidCoordinatePair(120, 28.3), false);
});

test('color helpers return distinct hex values for statuses and support categories', () => {
  assert.equal(getProjectStatusColor('complete'), '#10b981');
  assert.equal(getProjectStatusColor('stalled'), '#ef4444');
  assert.equal(getApplicationCategoryColor('Grant'), '#4f46e5');
  assert.equal(getApplicationCategoryColor('Bursary'), '#0ea5e9');
  assert.equal(getApplicationCategoryColor('Agricultural Support'), '#059669');
});
