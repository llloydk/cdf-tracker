import { ExpenditureAttachment } from '../types';
import { isImageFile } from './appHelpers';

export interface CompressOptions {
  maxDimension: number;
  targetMaxBytes: number;
  initialQuality: number;
}

function estimateDataUrlBytes(dataUrl: string): number {
  return new TextEncoder().encode(dataUrl).length;
}

function readBlobAsDataUrl(blob: Blob, label: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Could not read "${label}".`));
    reader.onload = () => resolve(String(reader.result || ''));
    reader.readAsDataURL(blob);
  });
}

type DecodedDrawable = {
  source: CanvasImageSource;
  width: number;
  height: number;
  cleanup: () => void;
};

async function decodeImageSafely(file: File): Promise<DecodedDrawable> {
  // Copy file bytes into an in-memory Blob immediately so resetting the <input>
  // or mobile camera temp-file cleanup cannot invalidate the handle mid-read.
  const buffer = await file.arrayBuffer();
  const stableBlob = new Blob([buffer], { type: file.type || 'image/png' });

  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(stableBlob);
      if (bitmap.width > 0 && bitmap.height > 0) {
        return {
          source: bitmap,
          width: bitmap.width,
          height: bitmap.height,
          cleanup: () => {
            try {
              bitmap.close();
            } catch {
              // ignore close errors
            }
          },
        };
      }
      bitmap.close();
    } catch {
      // Fall back to HTMLImageElement decoding below
    }
  }

  return new Promise((resolve, reject) => {
    const hasObjectUrl = typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function';
    const objectUrl = hasObjectUrl ? URL.createObjectURL(stableBlob) : '';
    const img = new Image();
    let settled = false;
    let fallbackTried = false;

    const cleanupUrl = () => {
      if (objectUrl) {
        try {
          URL.revokeObjectURL(objectUrl);
        } catch {
          // ignore revoke errors
        }
      }
    };

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      cleanupUrl();
      reject(new Error(`Timed out reading "${file.name}". Please try a smaller photo.`));
    }, 8000);

    const finishSuccess = (targetImg: HTMLImageElement, cleanup: () => void) => {
      if (settled) {
        cleanup();
        return;
      }
      settled = true;
      clearTimeout(timer);
      resolve({
        source: targetImg,
        width: Math.max(1, targetImg.naturalWidth || targetImg.width || 1),
        height: Math.max(1, targetImg.naturalHeight || targetImg.height || 1),
        cleanup,
      });
    };

    const finishError = (msg: string) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      cleanupUrl();
      reject(new Error(msg));
    };

    img.onload = () => finishSuccess(img, cleanupUrl);
    img.onerror = async () => {
      if (settled) return;
      if (objectUrl && !fallbackTried) {
        fallbackTried = true;
        cleanupUrl();
        try {
          const dataUrl = await readBlobAsDataUrl(stableBlob, file.name);
          const fallbackImg = new Image();
          fallbackImg.onload = () => finishSuccess(fallbackImg, () => {});
          fallbackImg.onerror = () => finishError(`"${file.name}" is not a valid readable image.`);
          fallbackImg.src = dataUrl;
          return;
        } catch {
          finishError(`"${file.name}" is not a valid readable image.`);
          return;
        }
      }
      finishError(`"${file.name}" is not a valid readable image.`);
    };

    if (objectUrl) {
      img.src = objectUrl;
    } else {
      readBlobAsDataUrl(stableBlob, file.name)
        .then((url) => {
          img.src = url;
        })
        .catch((err) => finishError(err?.message || `Could not read "${file.name}".`));
    }
  });
}

/**
 * Downscales and iteratively compresses an image File to JPEG within a strict
 * byte budget, avoiding holding huge raw camera base64 strings in memory.
 */
export async function compressImageToBudget(
  file: File,
  options: CompressOptions
): Promise<{ dataUrl: string; byteSize: number }> {
  if (file.size > 15 * 1024 * 1024) {
    throw new Error(`"${file.name}" exceeds the 15MB upload limit.`);
  }

  const { source, width: srcW, height: srcH, cleanup } = await decodeImageSafely(file);
  try {
    let maxDim = options.maxDimension;
    let quality = options.initialQuality;
    let bestDataUrl = '';

    for (let attempt = 0; attempt < 6; attempt++) {
      const scale = Math.min(1, maxDim / Math.max(srcW, srcH));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(srcW * scale));
      canvas.height = Math.max(1, Math.round(srcH * scale));
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('Could not initialize image compression canvas.');
      }

      // White backdrop prevents black boxes when converting transparent PNGs to JPEG
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(source, 0, 0, canvas.width, canvas.height);

      const candidate = canvas.toDataURL('image/jpeg', quality);
      bestDataUrl = candidate;

      if (estimateDataUrlBytes(candidate) <= options.targetMaxBytes) {
        return { dataUrl: candidate, byteSize: estimateDataUrlBytes(candidate) };
      }

      if (quality > 0.42) {
        quality = Number(Math.max(0.38, quality - 0.14).toFixed(2));
      } else {
        maxDim = Math.max(360, Math.round(maxDim * 0.72));
      }
    }

    return {
      dataUrl: bestDataUrl,
      byteSize: estimateDataUrlBytes(bestDataUrl),
    };
  } finally {
    cleanup();
  }
}

/**
 * Reads an uploaded File (image or small document) and returns a compact
 * ExpenditureAttachment suitable for Firestore document storage.
 * Images are compressed under ~140KB so multiple daily receipts/site photos
 * fit comfortably inside Firestore's 1 MiB project document limit.
 */
export async function processAttachmentFile(file: File): Promise<ExpenditureAttachment> {
  if (file.size > 15 * 1024 * 1024) {
    throw new Error(`"${file.name}" exceeds the 15MB upload limit.`);
  }

  if (isImageFile(file.name, file.type)) {
    const { dataUrl } = await compressImageToBudget(file, {
      maxDimension: 900,
      targetMaxBytes: 140 * 1024,
      initialQuality: 0.72,
    });
    return {
      id: 'ATT-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
      name: file.name,
      type: 'image/jpeg',
      dataUrl,
      uploadedAt: new Date().toISOString(),
    };
  }

  if (file.size > 220 * 1024) {
    throw new Error(
      `Non-image file "${file.name}" must be under 220KB (or upload a photo/screenshot instead).`
    );
  }

  const rawUrl = await readBlobAsDataUrl(file, file.name);
  return {
    id: 'ATT-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
    name: file.name,
    type: file.type || 'application/octet-stream',
    dataUrl: rawUrl,
    uploadedAt: new Date().toISOString(),
  };
}

/**
 * Compresses a citizen whistleblower evidence photo under ~220KB JPEG
 * cleanly without holding huge raw camera dataURLs in React state.
 */
export async function processEvidencePhoto(file: File): Promise<{ dataUrl: string; byteSize: number }> {
  if (!isImageFile(file.name, file.type)) {
    throw new Error('Please choose an image file (JPG, PNG, WEBP).');
  }
  return compressImageToBudget(file, {
    maxDimension: 1000,
    targetMaxBytes: 220 * 1024,
    initialQuality: 0.76,
  });
}
