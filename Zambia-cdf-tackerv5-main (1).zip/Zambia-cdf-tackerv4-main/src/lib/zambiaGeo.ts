import { Application, Project } from '../types';
import { getConstituencyByName } from '../constituencies';

export const ZAMBIA_CENTER: [number, number] = [-13.1339, 27.8493];
export const ZAMBIA_DEFAULT_ZOOM = 6;

export interface ResolvedCoordinates {
  lat: number;
  lng: number;
  source: 'gps' | 'constituency' | 'province';
}

/**
 * Geographic centroids for all 10 provinces in Zambia.
 */
export const PROVINCE_COORDS: Record<string, [number, number]> = {
  Lusaka: [-15.4167, 28.2833],
  Copperbelt: [-12.8024, 28.2132],
  Eastern: [-13.6333, 32.65],
  Southern: [-16.8089, 26.9875],
  Central: [-14.4469, 28.4464],
  Northern: [-10.2129, 31.1808],
  Western: [-15.2796, 23.137],
  'North-Western': [-12.1688, 26.3894],
  Luapula: [-11.1998, 28.8943],
  Muchinga: [-10.5414, 32.0816],
};

/**
 * Representative coordinates for Zambian towns, districts, and urban constituencies.
 */
const CONSTITUENCY_COORDS: Record<string, [number, number]> = {
  // Lusaka urban & district
  matero: [-15.367, 28.258],
  mandevu: [-15.349, 28.294],
  chawama: [-15.458, 28.273],
  kabwata: [-15.441, 28.297],
  kanyama: [-15.431, 28.241],
  munali: [-15.388, 28.347],
  'lusaka central': [-15.4167, 28.2833],
  roma: [-15.374, 28.316],
  makeni: [-15.468, 28.234],
  lima: [-15.35, 28.22],
  chilanga: [-15.552, 28.276],
  kafue: [-15.769, 28.181],
  chongwe: [-15.329, 28.682],
  chirundu: [-16.03, 28.85],
  rufunsa: [-15.083, 29.626],

  // Copperbelt
  nkana: [-12.815, 28.214],
  wusakile: [-12.843, 28.225],
  kwacha: [-12.785, 28.208],
  chimwemwe: [-12.771, 28.191],
  kamfinsa: [-12.86, 28.28],
  'ndola central': [-12.9587, 28.6366],
  chifubu: [-12.927, 28.613],
  kabushi: [-12.989, 28.64],
  'bwana mkubwa': [-13.027, 28.67],
  chingola: [-12.528, 27.883],
  nchanga: [-12.536, 27.854],
  mufulira: [-12.549, 28.24],
  kankoyo: [-12.56, 28.22],
  kantanshi: [-12.541, 28.258],
  luanshya: [-13.1367, 28.4166],
  roan: [-13.16, 28.368],
  kalulushi: [-12.841, 28.095],
  chambishi: [-12.642, 28.054],
  chililabombwe: [-12.364, 27.822],
  konkola: [-12.345, 27.805],
  mpongwe: [-13.509, 28.155],
  masaiti: [-13.218, 28.615],
  lufwanyama: [-13.065, 27.64],

  // Central
  'kabwe central': [-14.4469, 28.4464],
  bwacha: [-14.425, 28.462],
  'kapiri mposhi': [-13.971, 28.67],
  serenje: [-13.232, 30.235],
  mkushi: [-13.62, 29.394],
  mumbwa: [-14.982, 27.062],
  chisamba: [-14.983, 28.396],
  chitambo: [-12.93, 30.65],
  keembe: [-14.68, 28.01],
  katuba: [-15.16, 28.26],

  // Southern
  livingstone: [-17.8419, 25.8542],
  maramba: [-17.856, 25.865],
  kazungula: [-17.783, 25.267],
  choma: [-16.8089, 26.9875],
  mazabuka: [-15.856, 27.748],
  monze: [-16.2833, 27.4833],
  kalomo: [-17.033, 26.483],
  pemba: [-16.526, 27.363],
  siavonga: [-16.538, 28.709],
  sinazongwe: [-17.261, 27.46],
  gwembe: [-16.497, 27.61],
  namwala: [-15.75, 26.433],
  'itezhi-tezhi': [-15.752, 26.02],
  chikankata: [-15.96, 28.14],

  // Eastern
  'chipata central': [-13.6333, 32.65],
  'chipata north': [-13.57, 32.63],
  chipangali: [-13.29, 32.75],
  katete: [-14.058, 32.047],
  sinda: [-14.23, 31.716],
  petauke: [-14.242, 31.325],
  nyimba: [-14.557, 30.815],
  lundazi: [-12.292, 33.178],
  chadiza: [-14.067, 32.439],
  chama: [-11.213, 33.152],
  vubwi: [-14.12, 32.89],
  malambo: [-13.15, 31.86],

  // Luapula
  mansa: [-11.1998, 28.8943],
  nchelenge: [-9.345, 28.734],
  kawambwa: [-9.792, 29.079],
  mwense: [-10.384, 28.698],
  mwansabombwe: [-9.81, 28.77],
  bangweulu: [-11.356, 29.546],
  chifunabuli: [-11.08, 29.45],
  milenge: [-11.79, 29.45],
  chipili: [-10.74, 29.1],

  // Northern
  kasama: [-10.2129, 31.1808],
  mbala: [-8.8402, 31.3659],
  mpulungu: [-8.7623, 31.1141],
  luwingu: [-10.262, 29.927],
  mporokoso: [-9.372, 30.125],
  kaputa: [-8.469, 29.662],
  chilubi: [-11.14, 29.92],
  lunte: [-9.82, 30.65],

  // North-Western
  solwezi: [-12.1688, 26.3894],
  kalumbila: [-12.26, 25.43],
  lumwana: [-12.23, 25.84],
  kasempa: [-13.458, 25.834],
  mufumbwe: [-13.68, 24.8],
  kabompo: [-13.593, 24.201],
  zambezi: [-13.543, 23.105],
  mwinilunga: [-11.736, 24.429],
  chavuma: [-13.073, 22.681],
  manyinga: [-13.38, 24.49],
  "ikeleng'i": [-11.24, 24.27],

  // Western
  mongu: [-15.2796, 23.137],
  senanga: [-16.1167, 23.2667],
  sesheke: [-17.4759, 24.2968],
  kaoma: [-14.783, 24.8],
  kalabo: [-14.97, 22.68],
  lukulu: [-14.37, 23.24],
  shangombo: [-16.32, 22.12],
  sioma: [-16.65, 23.56],
  nalolo: [-15.53, 23.12],
  sikongo: [-15.05, 22.24],

  // Muchinga
  chinsali: [-10.5414, 32.0816],
  mpika: [-11.8343, 31.4529],
  isoka: [-10.1606, 32.6335],
  nakonde: [-9.3421, 32.745],
  mafinga: [-10.05, 33.24],
  "shiwan'gandu": [-11.17, 31.78],
  kanchibiya: [-11.55, 30.89],
};

function hashSeed(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function clampZambia(lat: number, lng: number): [number, number] {
  const clampedLat = Math.max(-18.0, Math.min(-8.3, lat));
  const clampedLng = Math.max(22.0, Math.min(33.6, lng));
  return [Number(clampedLat.toFixed(6)), Number(clampedLng.toFixed(6))];
}

function normalizeProvinceName(province?: string): string {
  const raw = (province || '').trim();
  if (!raw) return 'Lusaka';
  if (/north\s*-?\s*western/i.test(raw)) return 'North-Western';
  const match = Object.keys(PROVINCE_COORDS).find(
    (k) => k.toLowerCase() === raw.toLowerCase()
  );
  return match || 'Lusaka';
}

function findConstituencyCentroid(constituency?: string): [number, number] | null {
  const raw = (constituency || '').trim().toLowerCase();
  if (!raw) return null;
  if (CONSTITUENCY_COORDS[raw]) return CONSTITUENCY_COORDS[raw];

  // Match directional variants e.g. "Chongwe East", "Kafue West", "Kapiri Mposhi North"
  for (const [key, coords] of Object.entries(CONSTITUENCY_COORDS)) {
    if (raw === key || raw.startsWith(key + ' ') || key.startsWith(raw + ' ')) {
      return coords;
    }
  }
  return null;
}

export function isValidCoordinatePair(lat?: number | null, lng?: number | null): boolean {
  return (
    typeof lat === 'number' &&
    typeof lng === 'number' &&
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    lat >= -90 &&
    lat <= 90 &&
    lng >= -180 &&
    lng <= 180
  );
}

/**
 * Returns the representative center point for a constituency (used to center
 * the Support GPS Location Picker or fallback pins).
 */
export function resolveConstituencyCenter(
  constituencyName?: string,
  provinceName?: string
): { lat: number; lng: number; source: 'constituency' | 'province' } {
  const constMatch = findConstituencyCentroid(constituencyName);
  if (constMatch) {
    return { lat: constMatch[0], lng: constMatch[1], source: 'constituency' };
  }
  const lookedUp = constituencyName ? getConstituencyByName(constituencyName) : undefined;
  const normalizedProv = normalizeProvinceName(provinceName || lookedUp?.province);
  const provCoords = PROVINCE_COORDS[normalizedProv] || ZAMBIA_CENTER;
  return { lat: provCoords[0], lng: provCoords[1], source: 'province' };
}

/**
 * Resolves coordinates for a Project:
 *  - Uses explicit `project.lat` / `project.lng` when present ('gps').
 *  - Otherwise derives deterministic coordinates near its constituency or
 *    province centroid so projects across all 228+ constituencies remain spread cleanly.
 */
export function resolveProjectCoordinates(
  project: Pick<Project, 'id' | 'constituency' | 'province' | 'lat' | 'lng'>
): ResolvedCoordinates {
  if (isValidCoordinatePair(project.lat, project.lng)) {
    return {
      lat: Number(project.lat!.toFixed(6)),
      lng: Number(project.lng!.toFixed(6)),
      source: 'gps',
    };
  }

  const base = resolveConstituencyCenter(project.constituency, project.province);
  const spread = base.source === 'constituency' ? 0.09 : 0.42;
  const h1 = hashSeed(`${project.id}-${project.constituency}-lat`);
  const h2 = hashSeed(`${project.id}-${project.constituency}-lng`);
  const offsetLat = ((h1 % 1000) / 1000 - 0.5) * spread;
  const offsetLng = ((h2 % 1000) / 1000 - 0.5) * spread;
  const [lat, lng] = clampZambia(base.lat + offsetLat, base.lng + offsetLng);

  return {
    lat,
    lng,
    source: base.source,
  };
}

/**
 * Resolves coordinates for a Support Application:
 *  - Uses explicit `app.lat` / `app.lng` when present ('gps').
 *  - Optionally falls back to deterministic constituency/province coordinates when needed.
 */
export function resolveApplicationCoordinates(
  app: Pick<Application, 'id' | 'constituency' | 'lat' | 'lng'>
): ResolvedCoordinates {
  if (isValidCoordinatePair(app.lat, app.lng)) {
    return {
      lat: Number(app.lat!.toFixed(6)),
      lng: Number(app.lng!.toFixed(6)),
      source: 'gps',
    };
  }

  const base = resolveConstituencyCenter(app.constituency);
  const spread = base.source === 'constituency' ? 0.06 : 0.3;
  const h1 = hashSeed(`${app.id}-${app.constituency}-lat`);
  const h2 = hashSeed(`${app.id}-${app.constituency}-lng`);
  const offsetLat = ((h1 % 1000) / 1000 - 0.5) * spread;
  const offsetLng = ((h2 % 1000) / 1000 - 0.5) * spread;
  const [lat, lng] = clampZambia(base.lat + offsetLat, base.lng + offsetLng);

  return {
    lat,
    lng,
    source: base.source,
  };
}

export function getProjectStatusColor(status: Project['status']): string {
  switch (status) {
    case 'complete':
      return '#10b981'; // emerald-500
    case 'ongoing':
      return '#3b82f6'; // blue-500
    case 'stalled':
      return '#ef4444'; // red-500
    case 'planned':
    default:
      return '#f59e0b'; // amber-500
  }
}

export function getApplicationCategoryColor(category: Application['category']): string {
  switch (category) {
    case 'Grant':
      return '#4f46e5'; // indigo-600
    case 'Bursary':
      return '#0ea5e9'; // sky-500
    case 'Agricultural Support':
      return '#059669'; // emerald-600
    default:
      return '#64748b';
  }
}
