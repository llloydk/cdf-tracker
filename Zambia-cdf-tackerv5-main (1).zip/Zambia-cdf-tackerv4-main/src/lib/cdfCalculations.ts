import { DailyExpenditure, Project, Report } from '../types';
import { ConstituencyInfo } from '../constituencies';

export const CDF_PER_CONSTITUENCY = 30_400_000;

export interface ProjectMetrics {
  budget: number;
  spent: number;
  remaining: number;
  rawRemaining: number;
  overBudget: boolean;
  overBudgetAmount: number;
  pct: number;
  transparencyPct: number;
  dailyLogsCount: number;
  documentedLogsCount: number;
  latestContractor: string;
}

export interface ConstituencyMetrics extends ConstituencyInfo {
  projectsCount: number;
  totalProjectBudget: number;
  budget: number;
  spent: number;
  remaining: number;
  completeCount: number;
  stalledCount: number;
  ongoingCount: number;
  plannedCount: number;
  reportCount: number;
  score: number;
}

/**
 * Computes total spent for a project from its optional historical baseSpent
 * and all recorded daily expenditure entries.
 * - If dailyLogs exist and baseSpent is defined, spent = baseSpent + sum(dailyLogs).
 * - If dailyLogs exist and baseSpent is undefined, spent = sum(dailyLogs).
 * - If no dailyLogs exist yet, falls back to project.spent (or baseSpent).
 */
export function computeProjectSpent(
  project: Pick<Project, 'spent' | 'baseSpent' | 'dailyLogs'>
): number {
  const logs = project.dailyLogs || [];
  if (logs.length > 0) {
    const logsTotal = logs.reduce((sum, entry) => sum + Math.max(0, Number(entry.amount) || 0), 0);
    const base = Math.max(0, Number(project.baseSpent) || 0);
    return Math.round(base + logsTotal);
  }
  return Math.max(0, Math.round(Number(project.spent ?? project.baseSpent ?? 0) || 0));
}

/**
 * Computes documentation completeness (0 to 1) of a single daily expenditure entry.
 * Evaluates the 4 required transparency pillars:
 *  1. Where funds go (whereItGoes)
 *  2. Things/materials used on (materialsUsed)
 *  3. Contractor or company used (contractorName)
 *  4. Uploaded proof/receipt/photo (attachments)
 */
export function computeDailyLogCompleteness(entry: DailyExpenditure): number {
  let checks = 0;
  if ((entry.whereItGoes || '').trim().length > 0) checks += 1;
  if ((entry.materialsUsed || '').trim().length > 0) checks += 1;
  if ((entry.contractorName || '').trim().length > 0) checks += 1;
  if (Array.isArray(entry.attachments) && entry.attachments.length > 0) checks += 1;
  return checks / 4;
}

/**
 * Computes all synchronized financial and transparency metrics for a project.
 * Used identically by both the Admin maintenance registry and Citizen views.
 */
export function calculateProjectMetrics(project: Project): ProjectMetrics {
  const budget = Math.max(0, Math.round(Number(project.budget) || 0));
  const spent = computeProjectSpent(project);
  const rawRemaining = budget - spent;
  const remaining = Math.max(0, rawRemaining);
  const overBudget = budget > 0 ? spent > budget : spent > 0;
  const overBudgetAmount = overBudget ? spent - budget : 0;

  // Utilization / progress percentage derived strictly from budget & spent
  const pct = budget > 0 ? Math.min(100, Math.max(0, Math.round((spent / budget) * 100))) : 0;

  const logs = project.dailyLogs || [];
  const dailyLogsCount = logs.length;
  const documentedLogsCount = logs.filter((l) => computeDailyLogCompleteness(l) === 1).length;

  // Latest contractor from newest daily log (by date/recordedAt), else project.contractor
  let latestContractor = (project.contractor || '').trim();
  if (logs.length > 0) {
    const sorted = [...logs].sort((a, b) =>
      `${b.date || ''}_${b.recordedAt || ''}`.localeCompare(`${a.date || ''}_${a.recordedAt || ''}`)
    );
    const withContractor = sorted.find((l) => (l.contractorName || '').trim().length > 0);
    if (withContractor) {
      latestContractor = withContractor.contractorName.trim();
    }
  }

  // Transparency % calculation (0 - 100):
  // - 50 pts: Financial utilization (spent / budget, capped at 100% utilization)
  // - 50 pts: Documentation & proof completeness across daily logs
  //           (if legacy seeded project has spent > 0 but no daily logs yet, partial baseline credit by status)
  // - Penalties: -20 if stalled, -15 if overspent without updating budget
  let transparencyPct = 0;
  if (budget > 0 && (spent > 0 || dailyLogsCount > 0)) {
    const utilizationRatio = Math.min(1, spent / budget);
    const utilPoints = utilizationRatio * 50;

    let docPoints = 0;
    if (dailyLogsCount > 0) {
      const avgCompleteness =
        logs.reduce((sum, entry) => sum + computeDailyLogCompleteness(entry), 0) / dailyLogsCount;
      docPoints = avgCompleteness * 50;
    } else if (spent > 0) {
      // Seeded project before daily expenditure logging began
      docPoints =
        project.status === 'complete'
          ? 35
          : project.status === 'ongoing'
            ? 20
            : project.status === 'stalled'
              ? 5
              : 10;
    }

    const stalledPenalty = project.status === 'stalled' ? 20 : 0;
    const overspendPenalty = overBudget ? 15 : 0;
    transparencyPct = Math.round(
      Math.max(0, Math.min(100, utilPoints + docPoints - stalledPenalty - overspendPenalty))
    );
  }

  return {
    budget,
    spent,
    remaining,
    rawRemaining,
    overBudget,
    overBudgetAmount,
    pct,
    transparencyPct,
    dailyLogsCount,
    documentedLogsCount,
    latestContractor,
  };
}

/**
 * Returns an updated Project object with synchronized spent, remaining, pct,
 * transparencyPct, contractor, and lastUpdated fields ready for Firestore persistence.
 */
export function buildSyncedProjectPayload(
  project: Project,
  overrides: Partial<Project> = {}
): Project {
  const merged: Project = {
    ...project,
    ...overrides,
  };
  const metrics = calculateProjectMetrics(merged);
  const next: Project = {
    ...merged,
    budget: metrics.budget,
    spent: metrics.spent,
    remaining: metrics.remaining,
    pct: metrics.pct,
    transparencyPct: metrics.transparencyPct,
    lastUpdated: new Date().toISOString(),
  };
  if (metrics.latestContractor) {
    next.contractor = metrics.latestContractor;
  }
  return next;
}

/**
 * Computes constituency-level metrics and transparency score directly from its
 * Project Maintenance Registry entries (never from a manually typed score).
 * - If the constituency has 0 projects in the registry, transparency is 0%.
 * - Otherwise, transparency combines project registry transparency scores,
 *   constituency allocation utilization, and penalties for stalled projects or reports.
 */
export function calculateConstituencyMetrics(
  constituency: ConstituencyInfo,
  allProjects: Project[],
  allReports: Report[]
): ConstituencyMetrics {
  const constProjects = allProjects.filter((p) => p.constituency === constituency.name);
  const projectMetrics = constProjects.map((p) => ({
    project: p,
    metrics: calculateProjectMetrics(p),
  }));

  const allocated =
    constituency.allocated && constituency.allocated > 0
      ? Math.round(constituency.allocated)
      : CDF_PER_CONSTITUENCY;

  const totalProjectBudget = projectMetrics.reduce((sum, item) => sum + item.metrics.budget, 0);
  const spent = projectMetrics.reduce((sum, item) => sum + item.metrics.spent, 0);
  const remaining = Math.max(0, allocated - spent);

  const completeCount = constProjects.filter((p) => p.status === 'complete').length;
  const stalledCount = constProjects.filter((p) => p.status === 'stalled').length;
  const ongoingCount = constProjects.filter((p) => p.status === 'ongoing').length;
  const plannedCount = constProjects.filter((p) => p.status === 'planned').length;
  const reportCount = allReports.filter((r) => r.constituency === constituency.name).length;

  let score = 0;
  if (constProjects.length > 0) {
    // Budget-weighted average of project transparency scores (fallback to simple avg if budgets are 0)
    const weightedProjectTransparency =
      totalProjectBudget > 0
        ? projectMetrics.reduce(
            (sum, item) => sum + item.metrics.transparencyPct * item.metrics.budget,
            0
          ) / totalProjectBudget
        : projectMetrics.reduce((sum, item) => sum + item.metrics.transparencyPct, 0) /
          constProjects.length;

    // Allocation utilization factor (up to 25 pts) so changing constituency allocation
    // budget also updates transparency %
    const allocationUtilisationPts =
      allocated > 0 ? Math.min(1, spent / allocated) * 25 : 0;

    // Project registry weight (75% of project transparency)
    const registryPts = weightedProjectTransparency * 0.75;

    const stalledPenalty = Math.min(stalledCount * 8, 24);
    const reportPenalty = Math.min(reportCount * 4, 16);

    score = Math.round(
      Math.max(
        0,
        Math.min(100, registryPts + allocationUtilisationPts - stalledPenalty - reportPenalty)
      )
    );
  }

  return {
    ...constituency,
    allocated,
    projectsCount: constProjects.length,
    totalProjectBudget,
    budget: totalProjectBudget,
    spent,
    remaining,
    completeCount,
    stalledCount,
    ongoingCount,
    plannedCount,
    reportCount,
    score,
  };
}
