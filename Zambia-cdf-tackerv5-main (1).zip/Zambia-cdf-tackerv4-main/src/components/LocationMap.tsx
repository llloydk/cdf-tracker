import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { ZAMBIA_CENTER, ZAMBIA_DEFAULT_ZOOM } from '../lib/zambiaGeo';

export interface MapMarkerItem {
  id: string;
  lat: number;
  lng: number;
  title: string;
  subtitle: string;
  color: string;
  badge?: string;
  details?: string[];
  source?: 'gps' | 'constituency' | 'province';
  actionLabel?: string;
}

interface LocationMapProps {
  markers: MapMarkerItem[];
  heightClass?: string;
  center?: [number, number];
  zoom?: number;
  fitBoundsToMarkers?: boolean;
  onMarkerAction?: (id: string) => void;
  pickerMode?: boolean;
  pickedCoords?: { lat: number; lng: number } | null;
  onPickLocation?: (lat: number, lng: number) => void;
  emptyMessage?: string;
  testId?: string;
}

function escapeHtml(raw: string): string {
  return String(raw || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const PICKER_PIN_ICON = L.divIcon({
  className: 'cdf-picker-pin',
  html: `<div style="width:28px;height:28px;border-radius:9999px;background:#059669;border:3px solid #ffffff;box-shadow:0 3px 10px rgba(15,23,42,0.45);display:flex;align-items:center;justify-content:center;"><div style="width:8px;height:8px;border-radius:9999px;background:#ffffff;"></div></div>`,
  iconSize: [28, 28],
  iconAnchor: [14, 14],
});

export const LocationMap: React.FC<LocationMapProps> = ({
  markers,
  heightClass = 'h-[360px]',
  center = ZAMBIA_CENTER,
  zoom = ZAMBIA_DEFAULT_ZOOM,
  fitBoundsToMarkers = true,
  onMarkerAction,
  pickerMode = false,
  pickedCoords = null,
  onPickLocation,
  emptyMessage = 'No locations match the current filter.',
  testId = 'location-map',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const pickerLayerRef = useRef<L.LayerGroup | null>(null);

  const onMarkerActionRef = useRef(onMarkerAction);
  onMarkerActionRef.current = onMarkerAction;

  const onPickLocationRef = useRef(onPickLocation);
  onPickLocationRef.current = onPickLocation;

  // Initialize Leaflet map once
  useEffect(() => {
    const el = containerRef.current;
    if (!el || mapRef.current) return;

    const map = L.map(el, {
      center,
      zoom,
      zoomControl: true,
      scrollWheelZoom: false,
      zoomSnap: 0.25,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a>',
      maxZoom: 18,
    }).addTo(map);

    const markersLayer = L.layerGroup().addTo(map);
    const pickerLayer = L.layerGroup().addTo(map);

    mapRef.current = map;
    markersLayerRef.current = markersLayer;
    pickerLayerRef.current = pickerLayer;

    // Force size recalculation after mount / tab reveal
    const timer = window.setTimeout(() => {
      map.invalidateSize();
    }, 120);

    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => {
        map.invalidateSize();
      });
      observer.observe(el);
    }

    return () => {
      window.clearTimeout(timer);
      observer?.disconnect();
      map.remove();
      mapRef.current = null;
      markersLayerRef.current = null;
      pickerLayerRef.current = null;
    };
  }, []);

  // Wire picker click handler when pickerMode is enabled
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleClick = (e: L.LeafletMouseEvent) => {
      if (!pickerMode || !onPickLocationRef.current) return;
      const lat = Number(e.latlng.lat.toFixed(6));
      const lng = Number(e.latlng.lng.toFixed(6));
      onPickLocationRef.current(lat, lng);
    };

    if (pickerMode) {
      map.getContainer().style.cursor = 'crosshair';
      map.on('click', handleClick);
    } else {
      map.getContainer().style.cursor = '';
    }

    return () => {
      map.off('click', handleClick);
      if (map.getContainer()) {
        map.getContainer().style.cursor = '';
      }
    };
  }, [pickerMode]);

  // Render data markers & fit bounds
  useEffect(() => {
    const map = mapRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();

    if (markers.length === 0) {
      if (!pickedCoords) {
        map.setView(center, zoom);
      }
      return;
    }

    const latLngs: L.LatLngExpression[] = [];

    markers.forEach((m) => {
      if (!Number.isFinite(m.lat) || !Number.isFinite(m.lng)) return;
      const pos: L.LatLngExpression = [m.lat, m.lng];
      latLngs.push(pos);

      const circle = L.circleMarker(pos, {
        radius: m.source === 'gps' ? 8 : 6.5,
        fillColor: m.color,
        color: '#ffffff',
        weight: 2,
        opacity: 1,
        fillOpacity: 0.9,
      });

      const sourceLabel =
        m.source === 'gps'
          ? 'Exact GPS Pin'
          : m.source === 'constituency'
            ? 'Constituency Area'
            : 'Province Area';

      const detailsHtml = (m.details || [])
        .map((line) => `<div style="font-size:11px;color:#334155;margin-top:2px;">${escapeHtml(line)}</div>`)
        .join('');

      const badgeHtml = m.badge
        ? `<span style="display:inline-block;margin-top:4px;padding:2px 7px;border-radius:9999px;font-size:10px;font-weight:700;text-transform:uppercase;background:${escapeHtml(m.color)}20;color:${escapeHtml(m.color)};border:1px solid ${escapeHtml(m.color)}40;">${escapeHtml(m.badge)}</span>`
        : '';

      const actionHtml =
        m.actionLabel && onMarkerActionRef.current
          ? `<button type="button" data-map-action-id="${escapeHtml(m.id)}" style="margin-top:8px;width:100%;padding:6px 10px;border-radius:8px;border:none;background:#1e293b;color:#ffffff;font-size:11px;font-weight:600;cursor:pointer;">${escapeHtml(m.actionLabel)}</button>`
          : '';

      const popupHtml = `
        <div style="min-width:190px;max-width:250px;font-family:system-ui,-apple-system,sans-serif;">
          <div style="font-weight:700;font-size:12px;color:#0f172a;line-height:1.3;">${escapeHtml(m.title)}</div>
          <div style="font-size:11px;color:#64748b;margin-top:2px;">${escapeHtml(m.subtitle)}</div>
          ${badgeHtml}
          <div style="margin-top:6px;padding-top:5px;border-top:1px solid #e2e8f0;">
            ${detailsHtml}
            <div style="font-size:10px;color:#64748b;margin-top:4px;font-family:ui-monospace,monospace;">
              ${m.lat.toFixed(4)}, ${m.lng.toFixed(4)} • ${escapeHtml(sourceLabel)}
            </div>
          </div>
          ${actionHtml}
        </div>
      `;

      circle.bindPopup(popupHtml);
      circle.on('popupopen', (evt) => {
        const popupEl = evt.popup.getElement();
        if (!popupEl) return;
        const btn = popupEl.querySelector<HTMLButtonElement>('[data-map-action-id]');
        if (btn) {
          btn.onclick = () => {
            const targetId = btn.getAttribute('data-map-action-id');
            if (targetId && onMarkerActionRef.current) {
              onMarkerActionRef.current(targetId);
            }
          };
        }
      });

      circle.addTo(layer);
    });

    if (fitBoundsToMarkers && latLngs.length > 0 && !pickerMode) {
      if (latLngs.length === 1) {
        map.setView(latLngs[0], 11);
      } else {
        const bounds = L.latLngBounds(latLngs);
        map.fitBounds(bounds, { padding: [14, 14], maxZoom: 12 });
      }
    }
  }, [markers, fitBoundsToMarkers, pickerMode]);

  // Render picked marker & recenter in picker mode or explicit picked pin view
  useEffect(() => {
    const map = mapRef.current;
    const pickerLayer = pickerLayerRef.current;
    if (!map || !pickerLayer) return;

    pickerLayer.clearLayers();
    if (!pickedCoords || !Number.isFinite(pickedCoords.lat) || !Number.isFinite(pickedCoords.lng)) {
      return;
    }

    const pos: L.LatLngExpression = [pickedCoords.lat, pickedCoords.lng];
    const pin = L.marker(pos, { icon: PICKER_PIN_ICON, draggable: pickerMode });
    if (pickerMode) {
      pin.on('dragend', () => {
        const next = pin.getLatLng();
        if (onPickLocationRef.current) {
          onPickLocationRef.current(Number(next.lat.toFixed(6)), Number(next.lng.toFixed(6)));
        }
      });
    }
    pin.bindPopup(
      `<div style="font-family:system-ui,sans-serif;font-size:11px;"><strong>Selected GPS Pin</strong><br/><span style="font-family:ui-monospace,monospace;">${pickedCoords.lat.toFixed(6)}, ${pickedCoords.lng.toFixed(6)}</span></div>`
    );
    pin.addTo(pickerLayer);

    if (pickerMode || markers.length === 0) {
      map.setView(pos, Math.max(map.getZoom(), 11));
    }
  }, [pickedCoords, pickerMode, markers.length]);

  // Recenter when center/zoom props change cleanly in picker mode with no pin yet
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (pickerMode && !pickedCoords) {
      map.setView(center, zoom);
    }
  }, [center[0], center[1], zoom, pickerMode, pickedCoords]);

  return (
    <div
      className={`relative isolate z-0 w-full ${heightClass} rounded-xl overflow-hidden border border-bo bg-slate-100`}
      data-testid={testId}
      data-marker-count={markers.length}
    >
      <div ref={containerRef} className="w-full h-full" />
      {markers.length === 0 && !pickerMode && !pickedCoords && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center z-[500]">
          <div className="bg-white/95 border border-bo rounded-xl px-4 py-2 text-xs font-medium text-mu shadow-sm">
            {emptyMessage}
          </div>
        </div>
      )}
    </div>
  );
};
