import React from 'react';
import { AlertTriangle, Building2, Calendar, Edit3, MapPin, Package, ShieldCheck, X } from 'lucide-react';
import { ExpenditureAttachment, Project } from '../types';
import { calculateProjectMetrics } from '../lib/cdfCalculations';
import { zmw } from '../utils';

interface ProjectLedgerModalProps {
  project: Project;
  mpName: string;
  canAdminEdit: boolean;
  onClose: () => void;
  onOpenAdminEdit: () => void;
  onPreviewAttachment: (att: ExpenditureAttachment) => void;
}

export const ProjectLedgerModal: React.FC<ProjectLedgerModalProps> = ({
  project,
  mpName,
  canAdminEdit,
  onClose,
  onOpenAdminEdit,
  onPreviewAttachment,
}) => {
  const metrics = calculateProjectMetrics(project);
  const sortedLogs = [...(project.dailyLogs || [])].sort((a, b) =>
    `${b.date || ''}_${b.recordedAt || ''}`.localeCompare(`${a.date || ''}_${a.recordedAt || ''}`)
  );

  return (
    <div
      className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={`Project ledger for ${project.name}`}
    >
      <div className="bg-white w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl relative flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-bo bg-gradient-to-r from-forest to-leaf text-white flex justify-between items-start shrink-0">
          <div>
            <span className="text-[9px] uppercase tracking-widest font-bold text-yellow-400">
              PROJECT LEDGER SHEET • SYNCED WITH ADMIN REGISTRY
            </span>
            <h3 className="font-serif font-extrabold text-base md:text-lg leading-tight mt-0.5">
              {project.name}
            </h3>
            <p className="text-xs opacity-80 mt-0.5">
              {project.id} • {project.constituency} Constituency • {mpName}
            </p>
            {metrics.latestContractor && (
              <p className="text-[11px] text-indigo-100 mt-1 flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5" />
                <span>Contractor: <strong>{metrics.latestContractor}</strong></span>
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close project ledger"
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          {/* Synchronized Financial Flow Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-blue-50/60 border border-blue-100 rounded-xl p-3 text-center">
              <span className="text-[10px] text-mu uppercase block">Allocation Budget</span>
              <strong className="font-serif text-sm text-blue-800">{zmw(metrics.budget)}</strong>
            </div>
            <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-3 text-center">
              <span className="text-[10px] text-mu uppercase block">Funds Used</span>
              <strong className="font-serif text-sm text-emerald-800">{zmw(metrics.spent)}</strong>
            </div>
            <div className="bg-amber-50/60 border border-amber-100 rounded-xl p-3 text-center">
              <span className="text-[10px] text-mu uppercase block">Remaining Fund</span>
              <strong className="font-serif text-sm text-amber-800">{zmw(metrics.remaining)}</strong>
            </div>
            <div className="bg-indigo-50/60 border border-indigo-100 rounded-xl p-3 text-center">
              <span className="text-[10px] text-mu uppercase block">Transparency %</span>
              <strong className={`font-serif text-sm ${
                metrics.transparencyPct >= 75 ? 'text-emerald-700' :
                metrics.transparencyPct >= 45 ? 'text-amber-600' : 'text-red-600'
              }`}>
                {metrics.transparencyPct}%
              </strong>
            </div>
          </div>

          {/* Progress & Transparency Bars */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-semibold text-mu">
                <span>Fund Utilization</span>
                <span className="text-forest font-bold">{metrics.pct}%</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden border border-bo/50">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${metrics.pct}%`,
                    backgroundColor:
                      project.status === 'stalled'
                        ? '#ef4444'
                        : project.status === 'complete'
                          ? '#10b981'
                          : '#3b82f6',
                  }}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-semibold text-mu">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Auto-Calculated Transparency
                </span>
                <span className="text-emerald-700 font-bold">{metrics.transparencyPct}%</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden border border-bo/50">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${metrics.transparencyPct}%`,
                    backgroundColor:
                      metrics.transparencyPct >= 75
                        ? '#10b981'
                        : metrics.transparencyPct >= 45
                          ? '#f59e0b'
                          : '#ef4444',
                  }}
                />
              </div>
            </div>
          </div>

          {project.status === 'stalled' && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-red-800 leading-relaxed">
                <strong>Warning — High Risk Flagged:</strong> Budget allocation of {zmw(metrics.budget)} was committed, but the project is officially Stalled. ACC audit investigations might be active on this constituency.
              </div>
            </div>
          )}

          {/* Daily Fund Usage, Materials & Contractor Breakdown */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-serif font-bold text-sm text-ink">
                🧾 Daily Fund Usage, Materials & Contractor Ledger ({sortedLogs.length})
              </h4>
              <span className="text-[10px] text-mu">Live synced from Admin Registry</span>
            </div>

            {sortedLogs.length === 0 ? (
              <div className="bg-slate-50 border border-bo rounded-xl p-4 text-xs text-mu">
                No daily itemized expenditure logs have been uploaded for this project yet.
              </div>
            ) : (
              <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                {sortedLogs.map((entry) => (
                  <div key={entry.id} className="bg-slate-50/70 border border-bo rounded-xl p-3 space-y-2 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="inline-flex items-center gap-1 font-mono font-bold text-[11px] bg-white border border-bo px-2 py-0.5 rounded-md">
                        <Calendar className="w-3 h-3 text-indigo-600" /> {entry.date}
                      </span>
                      <span className="font-serif font-extrabold text-sm text-emerald-700">
                        {zmw(entry.amount)} used
                      </span>
                    </div>
                    <p className="text-ink font-semibold flex items-start gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                      <span>Where it goes: {entry.whereItGoes}</span>
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-white border border-bo/70 rounded-lg p-2">
                      <div className="flex items-start gap-1.5">
                        <Package className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[9px] font-bold text-mu uppercase block">Materials / Things Used</span>
                          <span className="text-ink">{entry.materialsUsed}</span>
                        </div>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[9px] font-bold text-mu uppercase block">Contractor / Company</span>
                          <span className="text-ink font-medium">{entry.contractorName}</span>
                        </div>
                      </div>
                    </div>
                    {entry.attachments && entry.attachments.length > 0 && (
                      <div className="flex flex-wrap gap-2 pt-1">
                        {entry.attachments.map((att) => (
                          <button
                            key={att.id}
                            type="button"
                            onClick={() => onPreviewAttachment(att)}
                            className="border border-bo bg-white hover:border-indigo-400 rounded-lg p-1 flex items-center gap-1.5 cursor-pointer"
                          >
                            {att.type.startsWith('image/') ? (
                              <img src={att.dataUrl} alt={att.name} className="w-10 h-10 rounded object-cover" />
                            ) : (
                              <span className="text-xs px-1">📄</span>
                            )}
                            <span className="text-[10px] text-slate-700 max-w-[140px] truncate pr-1">
                              {att.name}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Milestones list */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm text-ink">📍 Milestones Completion Chart</h4>
            <div className="space-y-3 pl-2.5 border-l-2 border-bo/80">
              {[
                { title: 'Project Charter & Allocation Approved', threshold: 10, desc: 'Tender assigned and allocations committed live' },
                { title: 'Ground Clearance & Foundations complete', threshold: 35, desc: 'Civil engineering structural foundations signed off' },
                { title: 'Superstructure walling & Roofing', threshold: 65, desc: 'Framing, roof panels, structural safety validated' },
                { title: 'Finishing & Official Handover', threshold: 100, desc: 'Community keys handed over to regional officials' },
              ].map((m, idx) => {
                const active = metrics.pct >= m.threshold;
                return (
                  <div key={idx} className="relative pl-5 space-y-0.5">
                    <span className={`absolute -left-[16px] top-0.5 w-2.5 h-2.5 rounded-full border-2 ${
                      active ? 'bg-emerald-500 border-emerald-500' : 'bg-white border-bo'
                    }`} />
                    <h5 className={`text-xs font-bold ${active ? 'text-ink' : 'text-mu'}`}>{m.title}</h5>
                    <p className="text-[10px] text-mu">{m.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-bg px-5 py-3 border-t border-bo flex justify-between items-center gap-2 shrink-0">
          {canAdminEdit ? (
            <button
              type="button"
              onClick={onOpenAdminEdit}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs py-2 px-4 rounded-xl cursor-pointer inline-flex items-center gap-1.5"
            >
              <Edit3 className="w-3.5 h-3.5" />
              Edit Project / Log Daily Spend
            </button>
          ) : (
            <span className="text-[11px] text-mu">Verified public transparency ledger</span>
          )}
          <button
            type="button"
            onClick={onClose}
            className="bg-forest hover:bg-leaf text-white font-semibold text-xs py-2 px-4 rounded-xl cursor-pointer"
          >
            Close audit sheet
          </button>
        </div>
      </div>
    </div>
  );
};
