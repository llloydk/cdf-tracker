import React, { useEffect } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  CheckCircle2,
  Clock,
  Eye,
  FileSpreadsheet,
  ShieldCheck,
  TrendingUp,
  X,
} from 'lucide-react';
import { Project } from '../types';
import { compareTwoProjects } from '../lib/projectComparison';
import { sLabel, zmw } from '../utils';

interface ProjectCompareModalProps {
  projectA: Project;
  projectB: Project;
  mpA: string;
  mpB: string;
  onSwap: () => void;
  onClearSelection: () => void;
  onInspectProject: (project: Project) => void;
  onClose: () => void;
}

function formatExactZmw(value: number): string {
  return 'K' + Math.round(value).toLocaleString();
}

function formatSignedZmw(diff: number): string {
  if (diff === 0) return 'K0';
  const prefix = diff > 0 ? '+' : '-';
  return `${prefix}${zmw(Math.abs(diff))}`;
}

function formatSignedPts(diff: number, unit = 'pts'): string {
  if (diff === 0) return 'Tied (0)';
  const sign = diff > 0 ? '+' : '';
  return unit === '%' ? `${sign}${diff}%` : `${sign}${diff} ${unit}`;
}

function getPlainStatusLabel(status: Project['status']): string {
  switch (status) {
    case 'complete':
      return 'Complete';
    case 'stalled':
      return 'Stalled';
    case 'ongoing':
      return 'Ongoing';
    case 'planned':
      return 'Planned';
    default:
      return sLabel(status);
  }
}

function StatusLabel({ status }: { status: Project['status'] }) {
  const icon =
    status === 'complete' ? (
      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
    ) : status === 'stalled' ? (
      <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0" />
    ) : status === 'ongoing' ? (
      <TrendingUp className="w-3.5 h-3.5 text-blue-600 shrink-0" />
    ) : (
      <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
    );

  const colorClass =
    status === 'complete'
      ? 'text-emerald-700'
      : status === 'stalled'
        ? 'text-red-700'
        : status === 'ongoing'
          ? 'text-blue-700'
          : 'text-slate-700';

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap ${colorClass}`}>
      {icon}
      <span>{getPlainStatusLabel(status)}</span>
    </span>
  );
}

export const ProjectCompareModal: React.FC<ProjectCompareModalProps> = ({
  projectA,
  projectB,
  mpA,
  mpB,
  onSwap,
  onClearSelection,
  onInspectProject,
  onClose,
}) => {
  const comparison = compareTwoProjects(projectA, projectB);
  const { left, right } = comparison;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 bg-black/75 z-[60] flex items-center justify-center p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={`Side-by-side comparison of ${projectA.name} and ${projectB.name}`}
      data-testid="project-compare-modal"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div>
            <p className="text-[11px] font-medium text-indigo-300 tracking-wide">
              Side-by-Side CDF Audit Comparison
            </p>
            <h3 className="font-serif font-bold text-lg text-white leading-tight mt-0.5">
              Project Efficiency, Transparency &amp; Status
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onSwap}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-medium border border-slate-700 whitespace-nowrap shrink-0 cursor-pointer transition-colors"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Swap A / B</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close comparison modal"
              className="text-slate-300 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1 bg-slate-50/50">
          {/* Top 2-Column Project Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-stretch">
            {[
              {
                slot: 'Project A',
                item: left,
                mp: mpA,
                isEffWinner: comparison.efficiencyLeader === 'left',
                isTransWinner: comparison.transparencyLeader === 'left',
              },
              {
                slot: 'Project B',
                item: right,
                mp: mpB,
                isEffWinner: comparison.efficiencyLeader === 'right',
                isTransWinner: comparison.transparencyLeader === 'right',
              },
            ].map(({ slot, item, mp, isEffWinner, isTransWinner }) => (
              <div
                key={item.project.id}
                className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-indigo-700">{slot}</span>
                    <StatusLabel status={item.project.status} />
                  </div>
                  <h4 className="font-serif font-bold text-base text-slate-900 leading-snug">
                    {item.project.name}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {item.project.constituency}
                    <span aria-hidden="true"> · </span>
                    {item.project.province}
                    <span aria-hidden="true"> · </span>
                    {item.project.sector}
                    <span aria-hidden="true"> · </span>
                    {mp}
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-100">
                  <div>
                    <div className="text-[11px] text-slate-500">Budget Efficiency</div>
                    <div className="mt-0.5 flex items-baseline gap-1.5">
                      <span className="text-lg font-bold text-slate-900 tabular-nums font-mono">
                        {item.budgetEfficiencyPct}%
                      </span>
                      {isEffWinner && (
                        <span className="text-[11px] font-semibold text-emerald-700">Higher</span>
                      )}
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-500">Transparency</div>
                    <div className="mt-0.5 flex items-baseline gap-1.5">
                      <span className="text-lg font-bold text-slate-900 tabular-nums font-mono">
                        {item.metrics.transparencyPct}%
                      </span>
                      {isTransWinner && (
                        <span className="text-[11px] font-semibold text-emerald-700">Higher</span>
                      )}
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-500">Fund Used</div>
                    <div className="mt-0.5 text-lg font-bold text-slate-900 tabular-nums font-mono">
                      {item.metrics.pct}%
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Visual Side-by-Side Metric Bars */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h4 className="font-serif font-bold text-sm text-slate-900">
                Performance &amp; Accountability Benchmarks
              </h4>
              <span className="text-xs text-slate-500">
                Efficiency adjusts fund utilization for delivery status and budget discipline
              </span>
            </div>

            <div className="space-y-4">
              {[
                {
                  label: 'Budget Efficiency',
                  valA: left.budgetEfficiencyPct,
                  valB: right.budgetEfficiencyPct,
                  subA: left.efficiencyNote,
                  subB: right.efficiencyNote,
                  leader: comparison.efficiencyLeader,
                  barColor: '#4f46e5',
                },
                {
                  label: 'Transparency Score',
                  valA: left.metrics.transparencyPct,
                  valB: right.metrics.transparencyPct,
                  subA: `${left.metrics.documentedLogsCount}/${left.metrics.dailyLogsCount} verified logs`,
                  subB: `${right.metrics.documentedLogsCount}/${right.metrics.dailyLogsCount} verified logs`,
                  leader: comparison.transparencyLeader,
                  barColor: '#059669',
                },
                {
                  label: 'Budget Utilization',
                  valA: left.metrics.pct,
                  valB: right.metrics.pct,
                  subA: `${zmw(left.metrics.spent)} of ${zmw(left.metrics.budget)}`,
                  subB: `${zmw(right.metrics.spent)} of ${zmw(right.metrics.budget)}`,
                  leader: left.metrics.pct === right.metrics.pct ? 'tie' : left.metrics.pct > right.metrics.pct ? 'left' : 'right',
                  barColor: '#0284c7',
                },
              ].map((row) => (
                <div key={row.label} className="space-y-2 pt-3 first:pt-0 border-t first:border-t-0 border-slate-100">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
                    <span>{row.label}</span>
                    <span className="font-mono tabular-nums text-slate-500">
                      Gap: {formatSignedPts(row.valA - row.valB, '%')}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { name: left.project.name, val: row.valA, sub: row.subA, isLead: row.leader === 'left' },
                      { name: right.project.name, val: row.valB, sub: row.subB, isLead: row.leader === 'right' },
                    ].map((side, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <span className="text-slate-700 truncate font-medium">
                            {idx === 0 ? 'A' : 'B'}: {side.name}
                          </span>
                          <span className={`font-mono tabular-nums font-bold shrink-0 ${side.isLead ? 'text-emerald-700' : 'text-slate-800'}`}>
                            {side.val}%
                          </span>
                        </div>
                        <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-300"
                            style={{ width: `${side.val}%`, backgroundColor: row.barColor }}
                          />
                        </div>
                        <p className="text-[11px] text-slate-500">{side.sub}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Detailed Side-by-Side Comparison Matrix */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h4 className="font-serif font-bold text-sm text-slate-900 flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
                <span>Metric-by-Metric Comparison</span>
              </h4>
              <span className="text-xs text-slate-500">Difference shown as Project A minus Project B</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/50">
                    <th className="py-3 px-4 font-semibold">Metric</th>
                    <th className="py-3 px-4 font-semibold text-slate-900">A: {left.project.name}</th>
                    <th className="py-3 px-4 font-semibold text-slate-900">B: {right.project.name}</th>
                    <th className="py-3 px-4 font-semibold text-right">Difference (A - B)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-700">Project Status</td>
                    <td className="py-3 px-4"><StatusLabel status={left.project.status} /></td>
                    <td className="py-3 px-4"><StatusLabel status={right.project.status} /></td>
                    <td className="py-3 px-4 text-right text-slate-600">
                      {left.project.status === right.project.status
                        ? 'Same status'
                        : `${getPlainStatusLabel(left.project.status)} vs ${getPlainStatusLabel(right.project.status)}`}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-700">Budget Efficiency</td>
                    <td className="py-3 px-4 font-mono tabular-nums font-bold text-slate-900">
                      {left.budgetEfficiencyPct}%
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums font-bold text-slate-900">
                      {right.budgetEfficiencyPct}%
                    </td>
                    <td className={`py-3 px-4 text-right font-mono tabular-nums font-semibold ${
                      comparison.efficiencyDiff > 0
                        ? 'text-emerald-700'
                        : comparison.efficiencyDiff < 0
                          ? 'text-amber-700'
                          : 'text-slate-500'
                    }`}>
                      {formatSignedPts(comparison.efficiencyDiff, '%')}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-700">
                      <span className="inline-flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        Transparency Score
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums font-bold text-slate-900">
                      {left.metrics.transparencyPct}%
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums font-bold text-slate-900">
                      {right.metrics.transparencyPct}%
                    </td>
                    <td className={`py-3 px-4 text-right font-mono tabular-nums font-semibold ${
                      comparison.transparencyDiff > 0
                        ? 'text-emerald-700'
                        : comparison.transparencyDiff < 0
                          ? 'text-amber-700'
                          : 'text-slate-500'
                    }`}>
                      {formatSignedPts(comparison.transparencyDiff, '%')}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-700">Allocated Budget</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-900">
                      {zmw(left.metrics.budget)} <span className="text-slate-400">({formatExactZmw(left.metrics.budget)})</span>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-900">
                      {zmw(right.metrics.budget)} <span className="text-slate-400">({formatExactZmw(right.metrics.budget)})</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatSignedZmw(comparison.budgetDiff)}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-700">Funds Spent</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-900">
                      {zmw(left.metrics.spent)} <span className="text-slate-500">({left.metrics.pct}%)</span>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-900">
                      {zmw(right.metrics.spent)} <span className="text-slate-500">({right.metrics.pct}%)</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatSignedZmw(comparison.spentDiff)}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-700">Remaining Funds</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-900">
                      {left.metrics.overBudget
                        ? `Over by ${zmw(left.metrics.overBudgetAmount)}`
                        : zmw(left.metrics.remaining)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-900">
                      {right.metrics.overBudget
                        ? `Over by ${zmw(right.metrics.overBudgetAmount)}`
                        : zmw(right.metrics.remaining)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatSignedZmw(comparison.remainingDiff)}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-700">Latest Contractor</td>
                    <td className="py-3 px-4 text-slate-700">
                      {left.metrics.latestContractor || 'Not recorded'}
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {right.metrics.latestContractor || 'Not recorded'}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-500">
                      {left.metrics.dailyLogsCount} vs {right.metrics.dailyLogsCount} logs
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-white px-5 py-3.5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onInspectProject(left.project);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium cursor-pointer transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              <span className="max-w-[160px] truncate">Inspect {left.project.name}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onInspectProject(right.project);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium cursor-pointer transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              <span className="max-w-[160px] truncate">Inspect {right.project.name}</span>
            </button>
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={() => {
                onClearSelection();
                onClose();
              }}
              className="px-3.5 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-medium cursor-pointer transition-colors"
            >
              Clear Selection
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold cursor-pointer transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
