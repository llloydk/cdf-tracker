import React, { useState, useEffect, useRef } from 'react';
import { X, Plus, Trash2, Upload, Building2, Package, MapPin, Calendar, CheckCircle, AlertTriangle, Edit3 } from 'lucide-react';
import { DailyExpenditure, ExpenditureAttachment, Project } from '../types';
import { ConstituencyInfo } from '../constituencies';
import { calculateProjectMetrics, computeDailyLogCompleteness, buildSyncedProjectPayload } from '../lib/cdfCalculations';
import { processAttachmentFile } from '../lib/imageUtils';
import { estimateDocumentBytes, sanitizeForFirestore } from '../lib/appHelpers';
import { resolveConstituencyCenter } from '../lib/zambiaGeo';
import { zmw } from '../utils';

interface AdminProjectEditModalProps {
  project: Project;
  constituencies: ConstituencyInfo[];
  constScope: string | null;
  adminActorLabel: string;
  onClose: () => void;
  onSaveProject: (
    updatedProject: Project,
    auditDescription: string,
    spentBefore: number,
    spentAfter: number
  ) => Promise<void>;
  onPreviewAttachment: (att: ExpenditureAttachment) => void;
}

const SECTORS = ['Education', 'Health', 'Roads', 'Water', 'Agriculture', 'Youth'];
const STATUSES: Project['status'][] = ['planned', 'ongoing', 'stalled', 'complete'];

export const AdminProjectEditModal: React.FC<AdminProjectEditModalProps> = ({
  project,
  constituencies,
  constScope,
  adminActorLabel,
  onClose,
  onSaveProject,
  onPreviewAttachment,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const draftStorageKey = `cdf_admin_log_draft_${project.id}`;
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const loadedProjectIdRef = useRef<string | null>(null);

  const readSavedDraft = (projId: string) => {
    try {
      const raw = sessionStorage.getItem(`cdf_admin_log_draft_${projId}`);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  };
  const initialDraft = readSavedDraft(project.id);

  // Project core fields
  const [name, setName] = useState(project.name);
  const [constituency, setConstituency] = useState(project.constituency);
  const [sector, setSector] = useState(project.sector);
  const [mp, setMp] = useState(project.mp);
  const [budget, setBudget] = useState(String(project.budget));
  const [status, setStatus] = useState<Project['status']>(project.status);
  const [contractor, setContractor] = useState(project.contractor || '');
  const [latInput, setLatInput] = useState(project.lat != null ? String(project.lat) : '');
  const [lngInput, setLngInput] = useState(project.lng != null ? String(project.lng) : '');
  const [baseSpent, setBaseSpent] = useState(
    String(
      project.dailyLogs && project.dailyLogs.length > 0
        ? (project.baseSpent ?? 0)
        : (project.baseSpent ?? project.spent ?? 0)
    )
  );
  const [dailyLogs, setDailyLogs] = useState<DailyExpenditure[]>(project.dailyLogs || []);

  // Daily fund entry form state (restored automatically if mobile browser reloads after camera picker)
  const [editingLogId, setEditingLogId] = useState<string | null>(initialDraft?.editingLogId ?? null);
  const [logDate, setLogDate] = useState<string>(initialDraft?.logDate || todayStr);
  const [logAmount, setLogAmount] = useState<string>(initialDraft?.logAmount || '');
  const [logWhereItGoes, setLogWhereItGoes] = useState<string>(initialDraft?.logWhereItGoes || '');
  const [logMaterials, setLogMaterials] = useState<string>(initialDraft?.logMaterials || '');
  const [logContractor, setLogContractor] = useState<string>(initialDraft?.logContractor ?? (project.contractor || ''));
  const [logContractorContact, setLogContractorContact] = useState<string>(initialDraft?.logContractorContact || '');
  const [logAttachments, setLogAttachments] = useState<ExpenditureAttachment[]>(
    Array.isArray(initialDraft?.logAttachments) ? initialDraft.logAttachments : []
  );
  const [logError, setLogError] = useState('');
  const [uploading, setUploading] = useState(false);

  const [saving, setSaving] = useState(false);
  const [saveNotice, setSaveNotice] = useState('');
  const [saveError, setSaveError] = useState('');

  // Reset form fields ONLY when switching to a different project ID; preserve active edits on snapshot updates
  useEffect(() => {
    if (loadedProjectIdRef.current !== project.id) {
      loadedProjectIdRef.current = project.id;
      setName(project.name);
      setConstituency(project.constituency);
      setSector(project.sector);
      setMp(project.mp);
      setBudget(String(project.budget));
      setStatus(project.status);
      setContractor(project.contractor || '');
      setLatInput(project.lat != null ? String(project.lat) : '');
      setLngInput(project.lng != null ? String(project.lng) : '');
      setDailyLogs(project.dailyLogs || []);
      setBaseSpent(
        String(
          project.dailyLogs && project.dailyLogs.length > 0
            ? (project.baseSpent ?? 0)
            : (project.baseSpent ?? project.spent ?? 0)
        )
      );
      const savedDraft = readSavedDraft(project.id);
      if (savedDraft) {
        setEditingLogId(savedDraft.editingLogId ?? null);
        setLogDate(savedDraft.logDate || todayStr);
        setLogAmount(savedDraft.logAmount || '');
        setLogWhereItGoes(savedDraft.logWhereItGoes || '');
        setLogMaterials(savedDraft.logMaterials || '');
        setLogContractor(savedDraft.logContractor ?? (project.contractor || ''));
        setLogContractorContact(savedDraft.logContractorContact || '');
        setLogAttachments(Array.isArray(savedDraft.logAttachments) ? savedDraft.logAttachments : []);
      }
    } else if (!saving) {
      setDailyLogs(project.dailyLogs || []);
    }
  }, [project.id, project.dailyLogs, saving]);

  // Persist daily log draft + attachments in sessionStorage so mobile browser resume keeps everything intact
  useEffect(() => {
    const hasDraftContent =
      Boolean(editingLogId) ||
      Boolean(logAmount) ||
      Boolean(logWhereItGoes) ||
      Boolean(logMaterials) ||
      Boolean(logContractorContact) ||
      logAttachments.length > 0;
    try {
      if (hasDraftContent) {
        sessionStorage.setItem(
          draftStorageKey,
          JSON.stringify({
            editingLogId,
            logDate,
            logAmount,
            logWhereItGoes,
            logMaterials,
            logContractor,
            logContractorContact,
            logAttachments,
          })
        );
      } else {
        sessionStorage.removeItem(draftStorageKey);
      }
    } catch {
      // Ignore storage quota errors cleanly
    }
  }, [
    draftStorageKey,
    editingLogId,
    logDate,
    logAmount,
    logWhereItGoes,
    logMaterials,
    logContractor,
    logContractorContact,
    logAttachments,
  ]);

  const parsedBudget = Math.max(0, Math.round(Number(budget) || 0));
  const parsedBaseSpent = Math.max(0, Math.round(Number(baseSpent) || 0));
  const parsedLat = latInput.trim() !== '' && Number.isFinite(Number(latInput)) ? Number(Number(latInput).toFixed(6)) : undefined;
  const parsedLng = lngInput.trim() !== '' && Number.isFinite(Number(lngInput)) ? Number(Number(lngInput).toFixed(6)) : undefined;

  const { lat: _oldLat, lng: _oldLng, ...projectRest } = project;
  const previewProject: Project = {
    ...projectRest,
    name: name.trim() || project.name,
    constituency: constScope || constituency,
    province:
      constituencies.find((c) => c.name === (constScope || constituency))?.province ||
      project.province,
    sector,
    mp: mp.trim() || project.mp,
    budget: parsedBudget,
    baseSpent: parsedBaseSpent,
    spent: dailyLogs.length > 0 ? parsedBaseSpent + dailyLogs.reduce((s, l) => s + l.amount, 0) : parsedBaseSpent,
    status,
    contractor: contractor.trim(),
    dailyLogs,
    ...(parsedLat != null && parsedLng != null ? { lat: parsedLat, lng: parsedLng } : {}),
  };

  const liveMetrics = calculateProjectMetrics(previewProject);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setLogError('');
    setSaveError('');
    const inputEl = e.currentTarget;
    const files: File[] = inputEl.files ? Array.from(inputEl.files) : [];
    if (files.length === 0) return;
    setUploading(true);
    try {
      const processed: ExpenditureAttachment[] = [];
      for (const file of files) {
        const att = await processAttachmentFile(file);
        processed.push(att);
      }
      setLogAttachments((prev) => [...prev, ...processed]);
    } catch (err: any) {
      setLogError(err?.message || 'Failed to upload attachment.');
    } finally {
      setUploading(false);
      if (inputEl) inputEl.value = '';
    }
  };

  const resetLogForm = () => {
    setEditingLogId(null);
    setLogDate(todayStr);
    setLogAmount('');
    setLogWhereItGoes('');
    setLogMaterials('');
    setLogContractor(contractor || liveMetrics.latestContractor || '');
    setLogContractorContact('');
    setLogAttachments([]);
    setLogError('');
    try {
      sessionStorage.removeItem(draftStorageKey);
    } catch {
      // ignore
    }
  };

  const handleCloseModal = () => {
    try {
      sessionStorage.removeItem(draftStorageKey);
    } catch {
      // ignore
    }
    onClose();
  };

  const handleStartEditLog = (entry: DailyExpenditure) => {
    setEditingLogId(entry.id);
    setLogDate(entry.date);
    setLogAmount(String(entry.amount));
    setLogWhereItGoes(entry.whereItGoes);
    setLogMaterials(entry.materialsUsed);
    setLogContractor(entry.contractorName);
    setLogContractorContact(entry.contractorContact || '');
    setLogAttachments(entry.attachments || []);
    setLogError('');
  };

  const handleSaveProjectDetails = async () => {
    setSaveNotice('');
    setSaveError('');
    setSaving(true);
    try {
      const synced = sanitizeForFirestore(buildSyncedProjectPayload(previewProject));
      if (estimateDocumentBytes(synced) > 920_000) {
        setSaveError('This project record has too much embedded attachment data for one Firestore document (>920KB). Please remove older receipt images first.');
        return;
      }
      await onSaveProject(
        synced,
        `Updated project details/budget (${zmw(synced.budget)} budget, ${zmw(synced.spent)} used, ${zmw(synced.remaining ?? 0)} remaining, ${synced.transparencyPct}% transparency)`,
        project.spent,
        synced.spent
      );
      setSaveNotice('Project details & auto-calculated transparency saved to live registry.');
    } catch (err: any) {
      setSaveError(err?.message || 'Could not save project details. Check database connection or permissions.');
    } finally {
      setSaving(false);
    }
  };

  const handleRecordDailyLog = async (e: React.FormEvent) => {
    e.preventDefault();
    setLogError('');
    setSaveNotice('');
    setSaveError('');

    const amt = Math.round(Number(logAmount) || 0);
    if (amt <= 0) {
      setLogError('Enter the funds used today (must be greater than K0).');
      return;
    }
    if (!logWhereItGoes.trim()) {
      setLogError('Specify where the funds went (work item / destination).');
      return;
    }
    if (!logMaterials.trim()) {
      setLogError('List the materials / items used on this expenditure.');
      return;
    }
    if (!logContractor.trim()) {
      setLogError('Enter the contractor or supplier company name used.');
      return;
    }

    // Preserve any prior seeded spent as baseSpent the very first time daily logs are added
    const initialBaseSpent =
      (project.dailyLogs || []).length === 0 && project.baseSpent == null
        ? Math.max(0, Number(baseSpent) || 0)
        : parsedBaseSpent;

    const newEntry: DailyExpenditure = {
      id: editingLogId || 'DAY-' + Date.now().toString(36).toUpperCase(),
      date: logDate || todayStr,
      amount: amt,
      whereItGoes: logWhereItGoes.trim(),
      materialsUsed: logMaterials.trim(),
      contractorName: logContractor.trim(),
      ...(logContractorContact.trim() ? { contractorContact: logContractorContact.trim() } : {}),
      ...(logAttachments.length > 0 ? { attachments: logAttachments } : {}),
      recordedBy: adminActorLabel,
      recordedAt: new Date().toISOString(),
    };

    const nextLogs = editingLogId
      ? dailyLogs.map((l) => (l.id === editingLogId ? newEntry : l))
      : [newEntry, ...dailyLogs];

    // If project was planned and funds are now used, automatically promote to ongoing (unless complete/stalled)
    const nextStatus: Project['status'] =
      status === 'planned' && amt > 0 ? 'ongoing' : status;

    const draft: Project = {
      ...previewProject,
      baseSpent: initialBaseSpent,
      dailyLogs: nextLogs,
      status: nextStatus,
      contractor: logContractor.trim() || previewProject.contractor,
    };

    const synced = sanitizeForFirestore(buildSyncedProjectPayload(draft));
    if (estimateDocumentBytes(synced) > 920_000) {
      setLogError(
        'Combined evidence photos on this project exceed the 920KB database safety cap. Remove an attachment or delete an older log photo before saving.'
      );
      return;
    }

    setSaving(true);
    try {
      await onSaveProject(
        synced,
        `${editingLogId ? 'Edited' : 'Logged'} daily spend (${newEntry.date}): ${zmw(amt)} to ${newEntry.contractorName} for "${newEntry.whereItGoes}" [${newEntry.materialsUsed}] — Transparency auto-updated to ${synced.transparencyPct}%`,
        project.spent,
        synced.spent
      );
      setDailyLogs(nextLogs);
      setBaseSpent(String(initialBaseSpent));
      setStatus(nextStatus);
      setContractor(synced.contractor || logContractor.trim());
      resetLogForm();
      setSaveNotice(
        `Daily expenditure recorded! Total Used: ${zmw(synced.spent)} • Remaining: ${zmw(synced.remaining ?? 0)} • Transparency: ${synced.transparencyPct}%`
      );
    } catch (err: any) {
      setLogError(err?.message || 'Could not sync daily entry to database. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteDailyLog = async (entryId: string) => {
    const target = dailyLogs.find((l) => l.id === entryId);
    if (!target) return;
    const nextLogs = dailyLogs.filter((l) => l.id !== entryId);
    const draft: Project = {
      ...previewProject,
      baseSpent: parsedBaseSpent,
      dailyLogs: nextLogs,
    };
    const synced = sanitizeForFirestore(buildSyncedProjectPayload(draft));
    setSaving(true);
    setSaveError('');
    try {
      await onSaveProject(
        synced,
        `Removed daily expenditure entry (${target.date}, ${zmw(target.amount)}) — Transparency recalculated to ${synced.transparencyPct}%`,
        project.spent,
        synced.spent
      );
      setDailyLogs(nextLogs);
      if (editingLogId === entryId) resetLogForm();
      setSaveNotice(`Entry removed. Remaining: ${zmw(synced.remaining ?? 0)} • Transparency: ${synced.transparencyPct}%`);
    } catch (err: any) {
      setSaveError(err?.message || 'Could not remove daily expenditure entry.');
    } finally {
      setSaving(false);
    }
  };

  const sortedLogs = [...dailyLogs].sort((a, b) =>
    `${b.date || ''}_${b.recordedAt || ''}`.localeCompare(`${a.date || ''}_${a.recordedAt || ''}`)
  );

  return (
    <div
      className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-3 md:p-5"
      role="dialog"
      aria-modal="true"
      aria-label={`Edit project ${project.name}`}
    >
      <div className="bg-white w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex justify-between items-start shrink-0">
          <div>
            <span className="text-[10px] uppercase tracking-widest font-bold text-amber-300">
              ADMIN PROJECT MAINTENANCE & DAILY FUND LEDGER
            </span>
            <h3 className="font-serif font-extrabold text-lg leading-tight mt-0.5">
              {name || project.name}
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              {project.id} • {constScope || constituency} Constituency • {mp}
            </p>
          </div>
          <button
            type="button"
            onClick={handleCloseModal}
            aria-label="Close project editor"
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hidden file input kept strictly OUTSIDE any form to prevent accidental submits or resets */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*,.pdf,.txt,.csv"
          onChange={handleFileUpload}
          className="hidden"
          aria-label="Upload evidence files or photos"
        />

        {/* Live Auto-Calculated Sync Bar */}
        <div className="bg-slate-50 border-b border-bo px-5 py-3 grid grid-cols-2 sm:grid-cols-5 gap-2.5 shrink-0">
          <div className="bg-white border border-blue-200 rounded-xl p-2.5 text-center">
            <span className="text-[9px] font-bold text-mu uppercase block">Budget</span>
            <strong className="font-serif text-sm text-blue-800">{zmw(liveMetrics.budget)}</strong>
          </div>
          <div className="bg-white border border-emerald-200 rounded-xl p-2.5 text-center">
            <span className="text-[9px] font-bold text-mu uppercase block">Total Funds Used</span>
            <strong className="font-serif text-sm text-emerald-700">{zmw(liveMetrics.spent)}</strong>
          </div>
          <div className={`bg-white border rounded-xl p-2.5 text-center ${liveMetrics.overBudget ? 'border-red-300 bg-red-50' : 'border-amber-200'}`}>
            <span className="text-[9px] font-bold text-mu uppercase block">Remaining Fund</span>
            <strong className={`font-serif text-sm ${liveMetrics.overBudget ? 'text-red-700' : 'text-amber-700'}`}>
              {zmw(liveMetrics.remaining)}
            </strong>
          </div>
          <div className="bg-white border border-indigo-200 rounded-xl p-2.5 text-center">
            <span className="text-[9px] font-bold text-mu uppercase block">Fund Utilization</span>
            <strong className="font-serif text-sm text-indigo-700">{liveMetrics.pct}%</strong>
          </div>
          <div className="bg-white border border-emerald-300 rounded-xl p-2.5 text-center col-span-2 sm:col-span-1">
            <span className="text-[9px] font-bold text-mu uppercase block">Auto Transparency</span>
            <strong className={`font-serif text-sm ${
              liveMetrics.transparencyPct >= 75 ? 'text-emerald-700' :
              liveMetrics.transparencyPct >= 45 ? 'text-amber-600' : 'text-red-600'
            }`}>
              {liveMetrics.transparencyPct}%
            </strong>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto flex-1 p-5 space-y-6">
          {saveError && (
            <div className="bg-red-50 border border-red-200 text-red-800 rounded-xl px-4 py-2.5 text-xs font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{saveError}</span>
            </div>
          )}

          {saveNotice && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl px-4 py-2.5 text-xs font-medium flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{saveNotice}</span>
            </div>
          )}

          {liveMetrics.overBudget && (
            <div className="bg-red-50 border border-red-200 text-red-800 rounded-xl px-4 py-2.5 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              <span>
                Total funds used ({zmw(liveMetrics.spent)}) exceeds the current budget ({zmw(liveMetrics.budget)}) by {zmw(liveMetrics.overBudgetAmount)}. Increase the allocation budget or adjust entries.
              </span>
            </div>
          )}

          {/* Section 1: Project Metadata & Budget */}
          <div className="bg-white border border-bo rounded-2xl p-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-bo pb-2.5">
              <div>
                <h4 className="font-serif font-bold text-sm text-ink">1. Project Registry Details & Budget</h4>
                <p className="text-[11px] text-mu">Changing the budget automatically recalculates remaining funds and transparency % for both admins and citizens.</p>
              </div>
              <button
                type="button"
                onClick={handleSaveProjectDetails}
                disabled={saving}
                className="bg-forest hover:bg-leaf disabled:opacity-50 text-white text-xs font-semibold px-4 py-2 rounded-xl cursor-pointer transition-colors"
              >
                {saving ? 'Saving...' : 'Save Project & Budget'}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
              <div className="space-y-1 sm:col-span-2">
                <label className="text-mu font-semibold block">Project Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs focus:outline-none focus:border-forest"
                />
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Allocation Budget (ZMW)</label>
                <input
                  type="number"
                  min={0}
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  className="w-full px-3 py-2 border border-blue-300 bg-blue-50/30 rounded-xl text-xs font-bold text-blue-900 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Constituency</label>
                {constScope ? (
                  <div className="px-3 py-2 border border-yellow-200 bg-yellow-50 rounded-xl text-xs font-bold text-yellow-800">
                    {constScope}
                  </div>
                ) : (
                  <select
                    value={constituency}
                    onChange={(e) => {
                      const val = e.target.value;
                      setConstituency(val);
                      const found = constituencies.find((c) => c.name === val);
                      if (found) setMp(found.mp);
                    }}
                    className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none"
                  >
                    {constituencies.map((c) => (
                      <option key={c.name} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Sector</label>
                <select
                  value={sector}
                  onChange={(e) => setSector(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none"
                >
                  {SECTORS.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as Project['status'])}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none"
                >
                  {STATUSES.map((st) => (
                    <option key={st} value={st}>{st.charAt(0).toUpperCase() + st.slice(1)}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Assigned MP</label>
                <input
                  type="text"
                  value={mp}
                  onChange={(e) => setMp(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Lead Contractor / Company</label>
                <input
                  type="text"
                  placeholder="e.g. Zambezi Civil Works Ltd"
                  value={contractor}
                  onChange={(e) => setContractor(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Prior Historical Spent (ZMW)</label>
                <input
                  type="number"
                  min={0}
                  value={baseSpent}
                  onChange={(e) => setBaseSpent(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs focus:outline-none"
                  title="Funds already disbursed before daily expenditure logging began"
                />
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Site Latitude (Optional GPS)</label>
                <input
                  type="number"
                  step="0.000001"
                  placeholder="e.g. -15.4167"
                  value={latInput}
                  onChange={(e) => setLatInput(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs font-mono focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-mu font-semibold block">Site Longitude (Optional GPS)</label>
                <input
                  type="number"
                  step="0.000001"
                  placeholder="e.g. 28.2833"
                  value={lngInput}
                  onChange={(e) => setLngInput(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs font-mono focus:outline-none"
                />
              </div>

              <div className="space-y-1 flex items-end">
                <button
                  type="button"
                  onClick={() => {
                    const center = resolveConstituencyCenter(constScope || constituency, previewProject.province);
                    setLatInput(String(center.lat));
                    setLngInput(String(center.lng));
                  }}
                  className="w-full px-3 py-2 border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
                >
                  📍 Fill Constituency Coords
                </button>
              </div>
            </div>
          </div>

          {/* Section 2: Daily Fund Usage Entry Form */}
          <div className="bg-indigo-50/40 border border-indigo-200 rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-indigo-200/70 pb-2.5">
              <div>
                <h4 className="font-serif font-bold text-sm text-indigo-950 flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-indigo-600" />
                  {editingLogId ? 'Edit Daily Fund Usage Entry' : '2. Record Daily Fund Usage, Materials & Contractor'}
                </h4>
                <p className="text-[11px] text-slate-600">
                  Log funds used each day, where the money went, materials/things used, the contractor/company, and upload receipts or site photos.
                </p>
              </div>
              {editingLogId && (
                <button
                  type="button"
                  onClick={resetLogForm}
                  className="text-xs font-semibold text-indigo-700 hover:underline cursor-pointer"
                >
                  Cancel Edit
                </button>
              )}
            </div>

            <form onSubmit={handleRecordDailyLog} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-700 font-semibold block">Date *</label>
                  <input
                    type="date"
                    value={logDate}
                    onChange={(e) => setLogDate(e.target.value)}
                    className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-700 font-semibold block">Funds Used Today (ZMW) *</label>
                  <input
                    type="number"
                    min={1}
                    placeholder="e.g. 125000"
                    value={logAmount}
                    onChange={(e) => setLogAmount(e.target.value)}
                    className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white font-semibold focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-700 font-semibold block">Contractor / Company Used *</label>
                  <input
                    type="text"
                    placeholder="e.g. Lusaka Hardware & Builders Ltd"
                    value={logContractor}
                    onChange={(e) => setLogContractor(e.target.value)}
                    className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-700 font-semibold block">Where Funds Go (Purpose / Work Area) *</label>
                  <input
                    type="text"
                    placeholder="e.g. Block B roofing trusses and classroom slab concrete"
                    value={logWhereItGoes}
                    onChange={(e) => setLogWhereItGoes(e.target.value)}
                    className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-700 font-semibold block">Contractor Contact / Reg / TPIN (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. 0977-000-000 / ZPPA Ref"
                    value={logContractorContact}
                    onChange={(e) => setLogContractorContact(e.target.value)}
                    className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 font-semibold block">Things / Materials Used On *</label>
                <textarea
                  rows={2}
                  placeholder="e.g. 200 bags cement, 40 roofing sheets, 15 tonnes river sand, labour & transport"
                  value={logMaterials}
                  onChange={(e) => setLogMaterials(e.target.value)}
                  className="w-full px-3 py-2 border border-bo rounded-xl text-xs bg-white focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="space-y-2">
                <span className="text-slate-700 font-semibold block">Upload Proof (Receipts, Material Photos, Delivery Notes)</span>
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    disabled={uploading || saving}
                    onClick={(ev) => {
                      ev.preventDefault();
                      ev.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                    className="inline-flex items-center gap-1.5 bg-white hover:bg-indigo-50 disabled:opacity-60 border border-indigo-300 text-indigo-700 font-semibold px-3 py-2 rounded-xl cursor-pointer transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploading ? 'Compressing photo...' : 'Upload Files / Photos'}</span>
                  </button>
                  <span className="text-[11px] text-mu">
                    Uploading proof maximizes the auto-calculated Transparency %.
                  </span>
                </div>

                {logAttachments.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {logAttachments.map((att) => (
                      <div key={att.id} className="relative bg-white border border-bo rounded-xl p-1.5 flex items-center gap-2">
                        {att.type.startsWith('image/') ? (
                          <img
                            src={att.dataUrl}
                            alt={att.name}
                            onClick={() => onPreviewAttachment(att)}
                            className="w-12 h-12 rounded-lg object-cover cursor-pointer"
                          />
                        ) : (
                          <button
                            type="button"
                            onClick={() => onPreviewAttachment(att)}
                            className="px-2 py-1 text-[11px] font-medium text-indigo-700 hover:underline cursor-pointer"
                          >
                            📄 {att.name}
                          </button>
                        )}
                        <button
                          type="button"
                          aria-label={`Remove ${att.name}`}
                          onClick={() => setLogAttachments((prev) => prev.filter((a) => a.id !== att.id))}
                          className="text-red-500 hover:text-red-700 p-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {logError && (
                <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-3 py-2 text-xs font-medium">
                  {logError}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="submit"
                  disabled={saving || uploading}
                  className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold text-xs px-5 py-2.5 rounded-xl cursor-pointer transition-colors"
                >
                  {saving
                    ? 'Syncing...'
                    : editingLogId
                      ? 'Update Daily Entry & Recalculate'
                      : 'Record Daily Fund Entry & Recalculate'}
                </button>
              </div>
            </form>
          </div>

          {/* Section 3: Daily Expenditure History */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-serif font-bold text-sm text-ink">
                3. Recorded Daily Expenditure Log ({sortedLogs.length})
              </h4>
              <span className="text-[11px] text-mu">
                Visible identically to citizens in the Project Ledger Sheet
              </span>
            </div>

            {sortedLogs.length === 0 ? (
              <div className="bg-slate-50 border border-bo rounded-xl p-5 text-center text-xs text-mu">
                No daily fund usage entries logged yet. Record today&apos;s spend above to start tracking materials, contractors, and receipts.
              </div>
            ) : (
              <div className="space-y-2.5">
                {sortedLogs.map((entry) => {
                  const scorePct = Math.round(computeDailyLogCompleteness(entry) * 100);
                  return (
                    <div key={entry.id} className="bg-white border border-bo rounded-xl p-3.5 space-y-2">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="space-y-0.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
                              <Calendar className="w-3 h-3" /> {entry.date}
                            </span>
                            <span className="text-sm font-serif font-extrabold text-emerald-700">
                              {zmw(entry.amount)}
                            </span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                              scorePct === 100 ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                            }`}>
                              {scorePct}% documented
                            </span>
                          </div>
                          <p className="text-xs font-semibold text-ink flex items-center gap-1 pt-1">
                            <MapPin className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                            <span>Where it went: {entry.whereItGoes}</span>
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleStartEditLog(entry)}
                            className="inline-flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[10px] font-bold px-2.5 py-1 rounded-lg cursor-pointer"
                          >
                            <Edit3 className="w-3 h-3" /> Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteDailyLog(entry.id)}
                            className="inline-flex items-center gap-1 bg-red-50 hover:bg-red-100 text-red-600 text-[10px] font-bold px-2.5 py-1 rounded-lg cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" /> Delete
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-slate-50 rounded-lg p-2.5 border border-bo/60">
                        <div className="flex items-start gap-1.5">
                          <Package className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-[10px] font-bold text-mu uppercase block">Materials / Things Used</span>
                            <span className="text-ink">{entry.materialsUsed}</span>
                          </div>
                        </div>
                        <div className="flex items-start gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-[10px] font-bold text-mu uppercase block">Contractor / Company</span>
                            <span className="text-ink font-medium">{entry.contractorName}</span>
                            {entry.contractorContact && (
                              <span className="text-[10px] text-mu block">{entry.contractorContact}</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {entry.attachments && entry.attachments.length > 0 && (
                        <div className="flex flex-wrap gap-2 pt-1">
                          {entry.attachments.map((att) => (
                            <button
                              key={att.id}
                              type="button"
                              onClick={() => onPreviewAttachment(att)}
                              className="group border border-bo rounded-lg p-1 bg-slate-50 hover:border-indigo-400 cursor-pointer flex items-center gap-1.5"
                            >
                              {att.type.startsWith('image/') ? (
                                <img src={att.dataUrl} alt={att.name} className="w-10 h-10 rounded object-cover" />
                              ) : (
                                <span className="text-xs px-1">📄</span>
                              )}
                              <span className="text-[10px] text-slate-700 group-hover:text-indigo-700 max-w-[140px] truncate pr-1">
                                {att.name}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-5 py-3 border-t border-bo flex justify-between items-center shrink-0">
          <span className="text-[11px] text-mu">
            All changes sync immediately to Citizen views via Firestore.
          </span>
          <button
            type="button"
            onClick={handleCloseModal}
            className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs py-2 px-4 rounded-xl cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
